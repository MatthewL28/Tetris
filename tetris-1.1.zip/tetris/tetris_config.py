# =============================================================================
#  TETRIS - Configuration File  (tetris_config.py)
#  Edit values here, or use the in-game settings menu (ESC during play).
#  Settings changed in-game are saved back to this file automatically.
# =============================================================================

import os
_DIR = os.path.dirname(os.path.abspath(__file__))

WINDOW_TITLE = "Tetris"
FPS          = 60
CELL_SIZE    = 32
MUSIC_FILE   = os.path.join(_DIR, "music.mp3")
MUSIC_VOLUME = 0.2
MUSIC_MUTED  = True
MUSIC_LOOP_START_MS    = 50
MUSIC_LOOP_END_TRIM_MS = 150
THEME        = "carbon"
HIGHSCORE_FILE  = os.path.join(_DIR, "highscores.txt")
HIGHSCORE_COUNT = 10

THEMES = {

    "default": {
        "name": "Default",
        "panel_bg":      ( 15,  15,  25),
        "grid_bg":       ( 20,  20,  30),
        "grid_line":     ( 35,  35,  50),
        "panel_fg":      (160, 160, 175),
        "panel_value":   (255, 255, 255),
        "panel_dim":     ( 50,  50,  65),
        "overlay_bg":    (  0,   0,   0, 160),
        "overlay_title": (255, 255, 255),
        "overlay_sub":   (160, 160, 175),
        "hud_text":      (160, 160, 175),
        "popup_color":   (255, 220,  50),
        "ghost_alpha":   80,
        "border_color":  ( 80,  80, 100),
        "piece_colors":  {"I":(0,220,220),"O":(230,200,0),"T":(180,0,200),"S":(0,210,60),"Z":(220,30,30),"J":(30,80,220),"L":(230,130,0)},
        "font_panel":    ("consolas", 20),
        "font_label":    ("consolas", 15),
        "font_large":    ("consolas", 28),
        "use_bevel": True, "scanlines": False, "calc_outline": False,
        "retro_dither": False, "retro_border": False, "nes_layout": False,
    },

    "nes": {
        "name": "NES Classic",
        "panel_bg":      (  0,   0, 110),
        "grid_bg":       (  0,   0,   0),
        "grid_line":     (  0,   0,   0),
        "panel_fg":      (255, 255, 255),
        "panel_value":   (255, 255, 255),
        "panel_dim":     (160, 160, 160),
        "overlay_bg":    (  0,   0,   0, 220),
        "overlay_title": (255, 255,   0),
        "overlay_sub":   (255, 255, 255),
        "hud_text":      (255, 255, 255),
        "popup_color":   (255, 255,   0),
        "ghost_alpha":   0,
        "border_color":  (255, 255, 255),
        "piece_colors":  {"I":(0,136,255),"O":(255,255,0),"T":(155,0,224),"S":(0,224,0),"Z":(224,0,0),"J":(0,224,224),"L":(255,155,0)},
        "font_panel":    ("consolas", 16),
        "font_label":    ("consolas", 13),
        "font_large":    ("consolas", 22),
        "use_bevel": False, "scanlines": True, "calc_outline": False,
        "retro_dither": False, "retro_border": False, "nes_layout": True,
    },

    "hacker": {
        "name": "Hacker",
        "panel_bg":      (  0,   0,   0),
        "grid_bg":       (  0,   0,   0),
        "grid_line":     ( 10,  30,  10),
        "panel_fg":      ( 50, 205,  50),
        "panel_value":   (  0, 255,   0),
        "panel_dim":     ( 20, 100,  20),
        "overlay_bg":    (  0,   0,   0, 210),
        "overlay_title": (  0, 255,   0),
        "overlay_sub":   ( 50, 205,  50),
        "hud_text":      ( 50, 205,  50),
        "popup_color":   (  0, 255,   0),
        "ghost_alpha":   50,
        "border_color":  ( 30, 140,  30),
        "piece_colors":  {"I":(0,220,0),"O":(0,220,0),"T":(0,220,0),"S":(0,220,0),"Z":(0,220,0),"J":(0,220,0),"L":(0,220,0)},
        "font_panel":    ("consolas", 17),
        "font_label":    ("consolas", 13),
        "font_large":    ("consolas", 24),
        "use_bevel": False, "scanlines": False, "calc_outline": False,
        "retro_dither": False, "retro_border": False, "nes_layout": False,
    },

    "calculator": {
        "name": "Calculator",
        "panel_bg":      (160, 165, 138),
        "grid_bg":       (168, 178, 140),
        "grid_line":     (150, 160, 125),
        "panel_fg":      ( 22,  26,  12),
        "panel_value":   (  6,   8,   2),
        "panel_dim":     ( 75,  82,  55),
        "overlay_bg":    (168, 178, 140, 220),
        "overlay_title": (  6,   8,   2),
        "overlay_sub":   ( 22,  26,  12),
        "hud_text":      ( 22,  26,  12),
        "popup_color":   (  6,   8,   2),
        "ghost_alpha":   0,
        "border_color":  ( 38,  42,  24),
        "piece_colors":  {"I":(18,22,10),"O":(18,22,10),"T":(18,22,10),"S":(18,22,10),"Z":(18,22,10),"J":(18,22,10),"L":(18,22,10)},
        "font_panel":    ("consolas", 17),
        "font_label":    ("consolas", 13),
        "font_large":    ("consolas", 24),
        "use_bevel": False, "scanlines": False, "calc_outline": True,
        "retro_dither": False, "retro_border": False, "nes_layout": False,
    },

    "earth": {
        "name": "Earth",
        "panel_bg":      ( 30,  45,  20),
        "grid_bg":       ( 18,  30,  10),
        "grid_line":     ( 35,  55,  20),
        "panel_fg":      (140, 180,  90),
        "panel_value":   (190, 230, 130),
        "panel_dim":     ( 70,  95,  40),
        "overlay_bg":    ( 18,  30,  10, 210),
        "overlay_title": (190, 230, 130),
        "overlay_sub":   (140, 180,  90),
        "hud_text":      (140, 180,  90),
        "popup_color":   (220, 255, 100),
        "ghost_alpha":   60,
        "border_color":  ( 80, 120,  40),
        "piece_colors":  {"I":(80,180,40),"O":(180,140,30),"T":(100,60,20),"S":(50,160,50),"Z":(160,90,20),"J":(40,100,60),"L":(200,130,30)},
        "font_panel":    ("consolas", 17),
        "font_label":    ("consolas", 13),
        "font_large":    ("consolas", 24),
        "use_bevel": True, "scanlines": False, "calc_outline": False,
        "retro_dither": False, "retro_border": False, "nes_layout": False,
    },

    "retro": {
        "name": "Retro",
        "panel_bg":      ( 80,  80,  80),
        "grid_bg":       (  0,   0,   0),
        "grid_line":     ( 15,  15,  15),
        "panel_fg":      (220, 220, 220),
        "panel_value":   (255, 255, 255),
        "panel_dim":     (140, 140, 140),
        "overlay_bg":    (  0,   0,   0, 200),
        "overlay_title": (255, 255, 255),
        "overlay_sub":   (200, 200, 200),
        "hud_text":      (220, 220, 220),
        "popup_color":   (255, 255, 180),
        "ghost_alpha":   50,
        "border_color":  (160, 160, 160),
        "piece_colors":  {"I":(0,188,188),"O":(0,188,188),"T":(120,80,200),"S":(0,188,188),"Z":(120,80,200),"J":(0,160,210),"L":(0,188,188)},
        "font_panel":    ("consolas", 18),
        "font_label":    ("consolas", 14),
        "font_large":    ("consolas", 24),
        "use_bevel": True, "scanlines": False, "calc_outline": False,
        "retro_dither": True, "retro_border": True, "nes_layout": False,
    },

    "noctua": {
        "name": "Noctua",
        "panel_bg":      ( 62,  38,  20),
        "grid_bg":       ( 45,  28,  12),
        "grid_line":     ( 72,  48,  25),
        "panel_fg":      (210, 175, 120),
        "panel_value":   (240, 210, 155),
        "panel_dim":     (130, 100,  65),
        "overlay_bg":    ( 30,  18,   5, 210),
        "overlay_title": (240, 210, 155),
        "overlay_sub":   (210, 175, 120),
        "hud_text":      (210, 175, 120),
        "popup_color":   (255, 230, 160),
        "ghost_alpha":   70,
        "border_color":  (150, 105,  55),
        "piece_colors":  {"I":(196,148,76),"O":(172,115,48),"T":(140,85,35),"S":(210,165,90),"Z":(115,68,25),"J":(185,135,65),"L":(228,185,110)},
        "font_panel":    ("consolas", 20),
        "font_label":    ("consolas", 15),
        "font_large":    ("consolas", 28),
        "use_bevel": True, "scanlines": False, "calc_outline": False,
        "retro_dither": False, "retro_border": False, "nes_layout": False,
    },

    "carbon": {
        "name": "Carbon",
        "panel_bg":      ( 18,  18,  18),
        "grid_bg":       ( 12,  12,  12),
        "grid_line":     ( 30,  30,  30),
        "panel_fg":      (200, 200, 200),
        "panel_value":   (255, 140,   0),
        "panel_dim":     ( 90,  90,  90),
        "overlay_bg":    (  0,   0,   0, 190),
        "overlay_title": (255, 140,   0),
        "overlay_sub":   (200, 200, 200),
        "hud_text":      (180, 180, 180),
        "popup_color":   (255, 160,  20),
        "ghost_alpha":   70,
        "border_color":  (255, 140,   0),
        "piece_colors":  {"I":(255,140,0),"O":(230,110,0),"T":(200,80,0),"S":(255,165,30),"Z":(180,60,0),"J":(240,125,10),"L":(255,155,40)},
        "font_panel":    ("consolas", 20),
        "font_label":    ("consolas", 15),
        "font_large":    ("consolas", 28),
        "use_bevel": True, "scanlines": False, "calc_outline": False,
        "retro_dither": False, "retro_border": False, "nes_layout": False,
    },

    "blackwhite": {
        "name": "Black & White",
        "panel_bg":      (  0,   0,   0),
        "grid_bg":       (  0,   0,   0),
        "grid_line":     ( 40,  40,  40),
        "panel_fg":      (255, 255, 255),
        "panel_value":   (255, 255, 255),
        "panel_dim":     (160, 160, 160),
        "overlay_bg":    (  0,   0,   0, 200),
        "overlay_title": (255, 255, 255),
        "overlay_sub":   (200, 200, 200),
        "hud_text":      (200, 200, 200),
        "popup_color":   (255, 255, 255),
        "ghost_alpha":   0,
        "border_color":  (255, 255, 255),
        "piece_colors":  {"I":(255,255,255),"O":(255,255,255),"T":(255,255,255),"S":(255,255,255),"Z":(255,255,255),"J":(255,255,255),"L":(255,255,255)},
        "font_panel":    ("consolas", 20),
        "font_label":    ("consolas", 15),
        "font_large":    ("consolas", 28),
        "use_bevel": False, "scanlines": False, "calc_outline": True,
        "retro_dither": False, "retro_border": False, "nes_layout": False,
    },
}

# =============================================================================
#  INTERNAL
# =============================================================================

KEY_MOVE_LEFT  = "a"
KEY_MOVE_RIGHT = "d"
KEY_ROTATE_CW  = "w"
KEY_SOFT_DROP  = "s"
KEY_HARD_DROP  = "space"
KEY_HOLD       = "f"
KEY_MUTE       = "m"
KEY_MINIMIZE   = "y"

GRID_COLS = 10
GRID_ROWS = 20

SCORE_SOFT_DROP_PER_ROW = 1
SCORE_HARD_DROP_PER_ROW = 2
SCORE_SINGLE            = 100
SCORE_DOUBLE            = 300
SCORE_TRIPLE            = 500
SCORE_TETRIS            = 800
SCORE_TSPIN             = 400
SCORE_TSPIN_SINGLE      = 800
SCORE_TSPIN_DOUBLE      = 1200
SCORE_TSPIN_TRIPLE      = 1600
SCORE_B2B_BONUS_FACTOR  = 0.5

LINES_PER_LEVEL    = 10
LOCK_DELAY         = 0.50
LOCK_RESETS_MAX    = 15
SOFT_DROP_INTERVAL = 0.05

GRAVITY_TABLE = {
     1: 0.800,  2: 0.717,  3: 0.633,  4: 0.550,  5: 0.467,
     6: 0.383,  7: 0.300,  8: 0.217,  9: 0.133, 10: 0.100,
    11: 0.083, 12: 0.083, 13: 0.067, 14: 0.067, 15: 0.067,
    16: 0.050, 17: 0.050, 18: 0.050, 19: 0.033, 20: 0.033,
    21: 0.033, 22: 0.033, 23: 0.033, 24: 0.033, 25: 0.033,
    26: 0.033, 27: 0.033, 28: 0.033, 29: 0.017,
}


def save_settings(theme, volume, muted, cell_size, music_file,
                  loop_start=None, loop_end_trim=None, keys=None):
    import re
    path = os.path.abspath(__file__)
    with open(path, "r") as f:
        src = f.read()

    def _rep(s, var, val):
        pat  = rf'^({var}\s*=\s*).*$'
        repl = rf'\g<1>"{val}"' if isinstance(val, str) else rf'\g<1>{val}'
        return re.sub(pat, repl, s, count=1, flags=re.MULTILINE)

    src = _rep(src, "THEME",        theme)
    src = _rep(src, "MUSIC_VOLUME", round(volume, 2))
    src = _rep(src, "MUSIC_MUTED",  muted)
    src = _rep(src, "CELL_SIZE",    cell_size)
    if loop_start is not None:
        src = _rep(src, "MUSIC_LOOP_START_MS",    int(loop_start))
    if loop_end_trim is not None:
        src = _rep(src, "MUSIC_LOOP_END_TRIM_MS", int(loop_end_trim))
    if keys:
        for var, val in keys.items():
            src = _rep(src, var, val)

    if re.search(r'^MUSIC_FILE\s*=\s*os\.path\.join', src, re.MULTILINE):
        bare = os.path.basename(music_file) if music_file else ""
        if bare:
            new_music = f'os.path.join(_DIR, "{bare}")'
            src = re.sub(r'^(MUSIC_FILE\s*=\s*).*$', rf'\g<1>{new_music}',
                         src, count=1, flags=re.MULTILINE)
    else:
        src = _rep(src, "MUSIC_FILE", music_file)

    with open(path, "w") as f:
        f.write(src)