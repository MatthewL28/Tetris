"""
tetris.py  -  main game file.
Configuration lives in tetris_config.py (same folder).
"""
import pygame, sys, os, random, time
import tetris_config as cfg

# ---------------------------------------------------------------------------
#  Piece data
# ---------------------------------------------------------------------------
PIECES = {
    "I": [[(0,-1),(0,0),(0,1),(0,2)],[(-1,1),(0,1),(1,1),(2,1)],[(1,-1),(1,0),(1,1),(1,2)],[(-1,0),(0,0),(1,0),(2,0)]],
    "O": [[(0,0),(0,1),(1,0),(1,1)],[(0,0),(0,1),(1,0),(1,1)],[(0,0),(0,1),(1,0),(1,1)],[(0,0),(0,1),(1,0),(1,1)]],
    "T": [[(0,-1),(0,0),(0,1),(-1,0)],[(-1,0),(0,0),(1,0),(0,1)],[(0,-1),(0,0),(0,1),(1,0)],[(-1,0),(0,0),(1,0),(0,-1)]],
    "S": [[(0,-1),(0,0),(-1,0),(-1,1)],[(-1,0),(0,0),(0,1),(1,1)],[(1,-1),(1,0),(0,0),(0,1)],[(-1,-1),(0,-1),(0,0),(1,0)]],
    "Z": [[(-1,-1),(-1,0),(0,0),(0,1)],[(-1,1),(0,0),(0,1),(1,0)],[(1,-1),(1,0),(0,0),(0,1)],[(-1,0),(0,-1),(0,0),(1,-1)]],
    "J": [[(0,-1),(0,0),(0,1),(-1,-1)],[(-1,0),(0,0),(1,0),(-1,1)],[(0,-1),(0,0),(0,1),(1,1)],[(-1,0),(0,0),(1,0),(1,-1)]],
    "L": [[(0,-1),(0,0),(0,1),(-1,1)],[(-1,0),(0,0),(1,0),(1,1)],[(0,-1),(0,0),(0,1),(1,-1)],[(-1,0),(0,0),(1,0),(-1,-1)]],
}
KICKS_JLSTZ = {
    (0,1):[(0,0),(-1,0),(-1,1),(0,-2),(-1,-2)],  (1,0):[(0,0),(1,0),(1,-1),(0,2),(1,2)],
    (1,2):[(0,0),(1,0),(1,-1),(0,2),(1,2)],        (2,1):[(0,0),(-1,0),(-1,1),(0,-2),(-1,-2)],
    (2,3):[(0,0),(1,0),(1,1),(0,-2),(1,-2)],        (3,2):[(0,0),(-1,0),(-1,-1),(0,2),(-1,2)],
    (3,0):[(0,0),(-1,0),(-1,-1),(0,2),(-1,2)],     (0,3):[(0,0),(1,0),(1,1),(0,-2),(1,-2)],
}
KICKS_I = {
    (0,1):[(0,0),(-2,0),(1,0),(-2,-1),(1,2)],   (1,0):[(0,0),(2,0),(-1,0),(2,1),(-1,-2)],
    (1,2):[(0,0),(-1,0),(2,0),(-1,2),(2,-1)],   (2,1):[(0,0),(1,0),(-2,0),(1,-2),(-2,1)],
    (2,3):[(0,0),(2,0),(-1,0),(2,1),(-1,-2)],   (3,2):[(0,0),(-2,0),(1,0),(-2,-1),(1,2)],
    (3,0):[(0,0),(1,0),(-2,0),(1,-2),(-2,1)],   (0,3):[(0,0),(-1,0),(2,0),(-1,2),(2,-1)],
}
def get_kick_table(pt): return KICKS_I if pt=="I" else KICKS_JLSTZ

# ---------------------------------------------------------------------------
#  Helpers
# ---------------------------------------------------------------------------
def gravity_interval(level): return cfg.GRAVITY_TABLE.get(level, 0.017)

def _score_salt():
    import hashlib
    a="t3tr"; b=bytes([0x31,0x73]).decode()
    c=str(cfg.GRID_COLS*cfg.GRID_ROWS*7+13)
    d="".join(chr(x) for x in [95,115,52,108,116])
    return hashlib.sha256((a+b+c+d).encode()).hexdigest()

def _entry_hash(score):
    import hashlib
    payload=f"{_score_salt()}:{score}:{_score_salt()}"
    return hashlib.sha256(payload.encode()).hexdigest()

def load_highscores():
    import base64
    scores=[]
    if not os.path.exists(cfg.HIGHSCORE_FILE): return scores
    try:
        with open(cfg.HIGHSCORE_FILE,"rb") as f: raw=base64.b64decode(f.read())
        for line in raw.decode().splitlines():
            line=line.strip()
            if not line: continue
            parts=line.split(":")
            if len(parts)!=2: continue
            sv=int(parts[0])
            if _entry_hash(sv)==parts[1]: scores.append(sv)
    except: pass
    return sorted(scores,reverse=True)[:cfg.HIGHSCORE_COUNT]

def save_highscore(score):
    import base64
    scores=load_highscores(); scores.append(score)
    scores=sorted(scores,reverse=True)[:cfg.HIGHSCORE_COUNT]
    lines=[f"{s}:{_entry_hash(s)}" for s in scores]
    encoded=base64.b64encode("\n".join(lines).encode())
    with open(cfg.HIGHSCORE_FILE,"wb") as f: f.write(encoded)

def active_theme(): return cfg.THEMES.get(cfg.THEME, cfg.THEMES["default"])
def window_size():
    s=cfg.CELL_SIZE; return cfg.GRID_COLS*s+320, cfg.GRID_ROWS*s+60

# ---------------------------------------------------------------------------
#  Music
# ---------------------------------------------------------------------------
_music_end_event = pygame.USEREVENT + 1

def setup_music():
    mf=cfg.MUSIC_FILE
    if mf and os.path.exists(mf):
        try:
            pygame.mixer.music.load(mf)
            pygame.mixer.music.set_volume(0 if cfg.MUSIC_MUTED else cfg.MUSIC_VOLUME)
            start_ms=max(0, cfg.MUSIC_LOOP_START_MS)
            pygame.mixer.music.play(0, start=start_ms/1000.0)
            pygame.mixer.music.set_endevent(_music_end_event)
            return True
        except: pass
    return False

def handle_music_end():
    """Called when USEREVENT fires – restart with correct loop offset."""
    mf=cfg.MUSIC_FILE
    if mf and os.path.exists(mf):
        try:
            start_ms=max(0, cfg.MUSIC_LOOP_START_MS)
            pygame.mixer.music.play(0, start=start_ms/1000.0)
        except: pass

# ---------------------------------------------------------------------------
#  Drawing primitives
# ---------------------------------------------------------------------------
def draw_cell(surface, color, row, col, ox, oy, size=None, bevel=True, dither=False):
    if size is None: size=cfg.CELL_SIZE
    x=ox+col*size; y=oy+row*size
    pygame.draw.rect(surface, color, (x+1,y+1,size-2,size-2))
    if bevel:
        lighter=tuple(min(255,v+60) for v in color)
        pygame.draw.line(surface,lighter,(x+1,y+1),(x+size-2,y+1),2)
        pygame.draw.line(surface,lighter,(x+1,y+1),(x+1,y+size-2),2)
    if dither:
        dot=max(3,size//5); lighter=tuple(min(255,v+90) for v in color)
        pygame.draw.rect(surface,lighter,(x+3,y+3,dot,dot))

def draw_cell_outline(surface, color, row, col, ox, oy, size=None):
    if size is None: size=cfg.CELL_SIZE
    x=ox+col*size; y=oy+row*size
    pygame.draw.rect(surface, color, (x+2,y+2,size-4,size-4), 1)

def draw_ghost(surface, cells, ox, oy, color, alpha, outline_only=False):
    if outline_only:
        for row,col in cells:
            if row>=0: draw_cell_outline(surface,color,row,col,ox,oy)
        return
    if alpha==0: return
    s=cfg.CELL_SIZE; gs=pygame.Surface((s-2,s-2),pygame.SRCALPHA)
    r,g,b=color; gs.fill((r,g,b,alpha))
    for row,col in cells:
        if row>=0:
            surface.blit(gs,(ox+col*s+1,oy+row*s+1))
            pygame.draw.rect(surface,color,(ox+col*s+1,oy+row*s+1,s-2,s-2),1)

def draw_grid(surface, board, ox, oy, theme):
    s=cfg.CELL_SIZE; bevel=theme.get("use_bevel",True); dither=theme.get("retro_dither",False)
    pygame.draw.rect(surface,theme["grid_bg"],(ox,oy,cfg.GRID_COLS*s,cfg.GRID_ROWS*s))
    for r in range(cfg.GRID_ROWS+1):
        pygame.draw.line(surface,theme["grid_line"],(ox,oy+r*s),(ox+cfg.GRID_COLS*s,oy+r*s))
    for c in range(cfg.GRID_COLS+1):
        pygame.draw.line(surface,theme["grid_line"],(ox+c*s,oy),(ox+c*s,oy+cfg.GRID_ROWS*s))
    for r in range(cfg.GRID_ROWS):
        for c in range(cfg.GRID_COLS):
            pt=board.grid[r][c]
            if pt:
                col=theme["piece_colors"].get(pt,(200,200,200))
                draw_cell(surface,col,r,c,ox,oy,bevel=bevel,dither=dither)

def draw_scanlines(surface, ox, oy):
    s=cfg.CELL_SIZE; w=cfg.GRID_COLS*s; h=cfg.GRID_ROWS*s
    sl=pygame.Surface((w,h),pygame.SRCALPHA)
    for y in range(0,h,2): pygame.draw.line(sl,(0,0,0,70),(0,y),(w,y))
    surface.blit(sl,(ox,oy))

def draw_nes_brick_border(surface, ox, oy, theme):
    s=cfg.CELL_SIZE; gw=cfg.GRID_COLS*s; gh=cfg.GRID_ROWS*s; bw=s
    col1=(0,0,160); col2=(0,0,224); col3=(0,0,80)
    for side in ["left","right","top","bottom"]:
        if side=="left":   tiles=[(ox-bw+bw//4, oy+r*s) for r in range(cfg.GRID_ROWS+2)]
        elif side=="right": tiles=[(ox+gw, oy+r*s) for r in range(cfg.GRID_ROWS+2)]
        elif side=="top":   tiles=[(ox+c*s-bw//4, oy-bw) for c in range(cfg.GRID_COLS+2)]
        else:               tiles=[(ox+c*s-bw//4, oy+gh) for c in range(cfg.GRID_COLS+2)]
        for i,(tx,ty) in enumerate(tiles):
            c=col1 if i%2==0 else col2
            pygame.draw.rect(surface,c,(tx,ty,s-1,s-1))
            pygame.draw.rect(surface,col3,(tx,ty,s-1,s-1),1)

def draw_retro_border(surface, ox, oy, theme):
    s=cfg.CELL_SIZE; gw=cfg.GRID_COLS*s; gh=cfg.GRID_ROWS*s; bw=s
    col1=(60,60,60); col2=(90,90,90); col3=(40,40,40)
    for side in ["left","right","top","bottom"]:
        if side=="left":   tiles=[(ox-bw+bw//4, oy+r*s) for r in range(cfg.GRID_ROWS+2)]
        elif side=="right": tiles=[(ox+gw, oy+r*s) for r in range(cfg.GRID_ROWS+2)]
        elif side=="top":   tiles=[(ox+c*s-bw//4, oy-bw) for c in range(cfg.GRID_COLS+2)]
        else:               tiles=[(ox+c*s-bw//4, oy+gh) for c in range(cfg.GRID_COLS+2)]
        for i,(tx,ty) in enumerate(tiles):
            c=col1 if i%2==0 else col2
            pygame.draw.rect(surface,c,(tx,ty,s-1,s-1))
            pygame.draw.rect(surface,col3,(tx,ty,s-1,s-1),1)
    pygame.draw.rect(surface,theme["border_color"],(ox,oy,gw,gh),2)

def mini_piece(surface, piece_type, cx, cy, theme, cell_size=20, outline=False):
    cells=PIECES[piece_type][0]
    rows_=[r for r,c in cells]; cols_=[c for r,c in cells]
    min_r=min(rows_); min_c=min(cols_)
    ox=cx-(max(cols_)-min_c+1)*cell_size//2; oy_=cy-(max(rows_)-min_r+1)*cell_size//2
    color=theme["piece_colors"][piece_type]
    bevel=theme.get("use_bevel",True); dither=theme.get("retro_dither",False)
    use_outline=outline or theme.get("calc_outline",False)
    for dr,dc in cells:
        x=ox+(dc-min_c)*cell_size; y=oy_+(dr-min_r)*cell_size
        if use_outline:
            pygame.draw.rect(surface,color,(x+2,y+2,cell_size-4,cell_size-4),1)
        else:
            pygame.draw.rect(surface,color,(x+1,y+1,cell_size-2,cell_size-2))
            if bevel:
                lighter=tuple(min(255,v+60) for v in color)
                pygame.draw.line(surface,lighter,(x+1,y+1),(x+cell_size-2,y+1),2)
                pygame.draw.line(surface,lighter,(x+1,y+1),(x+1,y+cell_size-2),2)
            if dither:
                dot=max(2,cell_size//5); lighter=tuple(min(255,v+90) for v in color)
                pygame.draw.rect(surface,lighter,(x+2,y+2,dot,dot))

def make_font(family, size, bold=False): return pygame.font.SysFont(family, size, bold=bold)
def render_centered(surface, text, font, color, cx, y):
    surf=font.render(text,True,color); surface.blit(surf,(cx-surf.get_width()//2,y)); return surf.get_height()
def render_left(surface, text, font, color, x, y):
    surf=font.render(text,True,color); surface.blit(surf,(x,y)); return surf.get_height()

# ---------------------------------------------------------------------------
#  Board / Piece / Bag
# ---------------------------------------------------------------------------
class Board:
    def __init__(self):
        # Store piece TYPE strings, not colours – so theme changes recolour instantly
        self.grid=[[None]*cfg.GRID_COLS for _ in range(cfg.GRID_ROWS)]

    def valid(self, cells):
        for r,c in cells:
            if c<0 or c>=cfg.GRID_COLS or r>=cfg.GRID_ROWS: return False
            if r>=0 and self.grid[r][c] is not None: return False
        return True

    def lock(self, piece):
        for r,c in piece.cells():
            if 0<=r<cfg.GRID_ROWS: self.grid[r][c]=piece.type  # store type, not colour

    def clear_lines(self):
        new_grid=[row for row in self.grid if any(cell is None for cell in row)]
        cleared=cfg.GRID_ROWS-len(new_grid)
        self.grid=[[None]*cfg.GRID_COLS for _ in range(cleared)]+new_grid
        return cleared

class Piece:
    def __init__(self, piece_type, theme):
        self.type=piece_type; self.rotation=0
        self.row=1; self.col=cfg.GRID_COLS//2-1
        self.color=theme["piece_colors"][piece_type]

    def refresh_color(self, theme):
        self.color=theme["piece_colors"][self.type]

    def cells(self, row=None, col=None, rotation=None):
        r=self.row if row is None else row
        c=self.col if col is None else col
        rot=self.rotation if rotation is None else rotation
        return [(r+dr,c+dc) for dr,dc in PIECES[self.type][rot%4]]

class Bag:
    def __init__(self): self.bag=[]
    def next(self, theme):
        if not self.bag: self.bag=list(PIECES.keys()); random.shuffle(self.bag)
        return Piece(self.bag.pop(), theme)

def detect_tspin(board, piece, last_was_rotation):
    if piece.type!="T" or not last_was_rotation: return "none"
    r,c=piece.row,piece.col
    corners=[(r-1,c-1),(r-1,c+1),(r+1,c-1),(r+1,c+1)]
    filled=sum(1 for cr,cc in corners if cr<0 or cr>=cfg.GRID_ROWS or cc<0 or cc>=cfg.GRID_COLS or board.grid[cr][cc] is not None)
    return "tspin" if filled>=3 else "none"

# ===========================================================================
#  Main Menu
# ===========================================================================
class MainMenu:
    ITEMS=["PLAY","SETTINGS","HIGH SCORES","QUIT"]
    def __init__(self, screen):
        self.screen=screen; self.sel=0; self._anim=0.0
        self._item_rects=[]; self._bg_pieces=self._make_bg()
        self._make_fonts()

    def _make_fonts(self):
        self.f_title=make_font("consolas",54,bold=True)
        self.f_item=make_font("consolas",28); self.f_sel=make_font("consolas",30,bold=True)
        self.f_small=make_font("consolas",14)

    def _make_bg(self):
        W,H=self.screen.get_size(); pieces=[]
        colors=list(cfg.THEMES["default"]["piece_colors"].values())
        for _ in range(18):
            pieces.append({"x":random.randint(0,W),"y":random.randint(0,H),
                           "size":random.randint(14,30),"color":random.choice(colors),
                           "speed":random.uniform(0.3,1.0),"alpha":random.randint(30,80)})
        return pieces

    def handle_event(self, event):
        if event.type==pygame.KEYDOWN:
            if event.key in (pygame.K_UP,pygame.K_w): self.sel=(self.sel-1)%len(self.ITEMS)
            elif event.key in (pygame.K_DOWN,pygame.K_s): self.sel=(self.sel+1)%len(self.ITEMS)
            elif event.key in (pygame.K_RETURN,pygame.K_SPACE): return self.ITEMS[self.sel]
        if event.type==pygame.MOUSEMOTION:
            for i,rect in enumerate(self._item_rects):
                if rect.collidepoint(event.pos): self.sel=i
        if event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
            for i,rect in enumerate(self._item_rects):
                if rect.collidepoint(event.pos): return self.ITEMS[i]
        return None

    def draw(self, dt):
        import math; self._anim+=dt*0.002
        W,H=self.screen.get_size(); self.screen.fill((10,10,20)); cx=W//2
        # bg pieces
        for p in self._bg_pieces:
            p["y"]+=p["speed"]*dt*0.06
            if p["y"]>H+40: p["y"]=-40; p["x"]=random.randint(0,W)
            s=pygame.Surface((p["size"],p["size"]),pygame.SRCALPHA)
            r,g,b=p["color"]; s.fill((r,g,b,p["alpha"])); self.screen.blit(s,(p["x"],p["y"]))
        wobble=int(math.sin(self._anim)*4)
        render_centered(self.screen,"TETRIS",self.f_title,(80,180,255),cx,H//4-40+wobble)
        render_centered(self.screen,"Use arrow keys or mouse",self.f_small,(60,60,80),cx,H//4+30)
        item_h=52; start_y=H//2-(len(self.ITEMS)*item_h)//2; self._item_rects=[]
        for i,label in enumerate(self.ITEMS):
            y=start_y+i*item_h; sel=(i==self.sel)
            col=(255,220,50) if sel else (160,160,185)
            f=self.f_sel if sel else self.f_item
            surf=f.render(label,True,col)
            rx=cx-surf.get_width()//2
            self._item_rects.append(pygame.Rect(rx-10,y-4,surf.get_width()+20,surf.get_height()+8))
            if sel:
                pygame.draw.rect(self.screen,(30,30,55),self._item_rects[-1],border_radius=6)
                pygame.draw.rect(self.screen,(80,80,140),self._item_rects[-1],1,border_radius=6)
                render_centered(self.screen,">> "+label+" <<",f,col,cx,y)
            else:
                render_centered(self.screen,label,f,col,cx,y)
        render_centered(self.screen,"Up/Down navigate   Enter select",self.f_small,(50,50,70),cx,H-30)

# ===========================================================================
#  High Scores Screen
# ===========================================================================
class HighScoresScreen:
    def __init__(self, screen):
        self.screen=screen
        self.f_title=make_font("consolas",36,bold=True)
        self.f_entry=make_font("consolas",22)
        self.f_small=make_font("consolas",14)

    def handle_event(self, event):
        if event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN): return True
        return False

    def draw(self):
        W,H=self.screen.get_size(); cx=W//2
        scores=load_highscores(); t=active_theme()
        self.screen.fill(t["panel_bg"])
        render_centered(self.screen,"HIGH SCORES",self.f_title,t["panel_value"],cx,40)
        pygame.draw.line(self.screen,t["border_color"],(cx-180,90),(cx+180,90),2)
        if not scores:
            render_centered(self.screen,"No scores yet - play a game!",self.f_entry,t["panel_fg"],cx,H//2-20)
        else:
            medals=["  #1","  #2","  #3"]
            gold=(255,215,0); silver=(192,192,192); bronze=(205,127,50)
            medal_cols=[gold,silver,bronze]
            for i,s in enumerate(scores):
                y=110+i*38
                rank=medals[i] if i<3 else f"  #{i+1}"
                col=medal_cols[i] if i<3 else t["panel_fg"]
                render_centered(self.screen,f"{rank}   {s:>10,}",self.f_entry,col,cx,y)
        pygame.draw.line(self.screen,t["border_color"],(cx-180,H-55),(cx+180,H-55),2)
        render_centered(self.screen,"Press any key to return",self.f_small,t["panel_dim"],cx,H-40)

# ===========================================================================
#  Settings Screen
# ===========================================================================
KEYBIND_VARS = [
    ("KEY_MOVE_LEFT",  "Move Left"),
    ("KEY_MOVE_RIGHT", "Move Right"),
    ("KEY_ROTATE_CW",  "Rotate"),
    ("KEY_SOFT_DROP",  "Soft Drop"),
    ("KEY_HARD_DROP",  "Hard Drop"),
    ("KEY_HOLD",       "Hold"),
    ("KEY_MUTE",       "Mute"),
    ("KEY_MINIMIZE",   "Minimize"),
]

class SettingsScreen:
    THEME_KEYS  = list(cfg.THEMES.keys())

    def __init__(self, screen, game_ref=None):
        self.screen=screen; self.game=game_ref; self.open=False
        self.advanced=False; self.keybinds_open=False
        self._clickables={}; self._waiting_for_key=None
        self._confirm_quit=False
        self._reset()

    def _reset(self):
        self._theme=cfg.THEME; self._volume=cfg.MUSIC_VOLUME
        self._muted=cfg.MUSIC_MUTED; self._cell_size=cfg.CELL_SIZE
        self._music_file=cfg.MUSIC_FILE
        self._music_input=os.path.basename(cfg.MUSIC_FILE) if cfg.MUSIC_FILE else ""
        self._loop_start=cfg.MUSIC_LOOP_START_MS
        self._loop_end_trim=cfg.MUSIC_LOOP_END_TRIM_MS
        self._keys={v:getattr(cfg,v,"") for v,_ in KEYBIND_VARS}
        self._editing_music=False; self._status=""; self._status_t=0
        self._confirm_quit=False; self._waiting_for_key=None

    def _make_fonts(self):
        self.f_title=make_font("consolas",28,bold=True)
        self.f_label=make_font("consolas",17)
        self.f_value=make_font("consolas",17)
        self.f_small=make_font("consolas",13)
        self.f_btn=make_font("consolas",16)

    def show(self):
        self.open=True; self.advanced=False; self.keybinds_open=False
        self._reset(); self._make_fonts()
        # Pause music when settings open
        if pygame.mixer.music.get_busy(): pygame.mixer.music.pause()

    def hide(self):
        self.open=False; self._waiting_for_key=None; self._confirm_quit=False
        # Resume music
        if not cfg.MUSIC_MUTED: pygame.mixer.music.unpause()

    def handle_event(self, event):
        if not self.open: return False
        if self._waiting_for_key is not None:
            if event.type==pygame.KEYDOWN:
                key_name=pygame.key.name(event.key)
                if event.key!=pygame.K_ESCAPE:
                    self._keys[self._waiting_for_key]=key_name
                self._waiting_for_key=None
            return True
        if self._confirm_quit:
            if event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
                for name,rect in self._clickables.items():
                    if rect.collidepoint(event.pos): self._on_click(name); break
            if event.type==pygame.KEYDOWN and event.key==pygame.K_ESCAPE:
                self._confirm_quit=False
            return True
        if event.type==pygame.KEYDOWN:
            if self._editing_music:
                if event.key==pygame.K_RETURN: self._editing_music=False
                elif event.key==pygame.K_BACKSPACE: self._music_input=self._music_input[:-1]
                elif event.key==pygame.K_ESCAPE: self._editing_music=False
                elif event.unicode and event.unicode.isprintable(): self._music_input+=event.unicode
            else:
                if event.key==pygame.K_ESCAPE:
                    self.hide()
                    if self.game: self.game.paused=False
            return True
        if event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
            for name,rect in self._clickables.items():
                if rect.collidepoint(event.pos): self._on_click(name); break
            return True
        return True

    def _on_click(self, name):
        if name=="close":
            self.hide()
            if self.game: self.game.paused=False
        elif name=="cancel":
            self.hide()
            if self.game: self.game.paused=False
        elif name=="advanced_toggle": self.advanced=not self.advanced
        elif name=="keybinds_toggle": self.keybinds_open=not self.keybinds_open
        elif name=="theme_prev":
            idx=self.THEME_KEYS.index(self._theme)
            self._theme=self.THEME_KEYS[(idx-1)%len(self.THEME_KEYS)]
        elif name=="theme_next":
            idx=self.THEME_KEYS.index(self._theme)
            self._theme=self.THEME_KEYS[(idx+1)%len(self.THEME_KEYS)]
        elif name=="vol_down": self._volume=max(0.0,round(self._volume-0.05,2))
        elif name=="vol_up":   self._volume=min(1.0,round(self._volume+0.05,2))
        elif name=="mute_toggle": self._muted=not self._muted
        elif name=="cell_down": self._cell_size=max(16,self._cell_size-2)
        elif name=="cell_up":   self._cell_size=min(48,self._cell_size+2)
        elif name=="loop_start_down": self._loop_start=max(0,self._loop_start-50)
        elif name=="loop_start_up":   self._loop_start+=50
        elif name=="loop_end_down": self._loop_end_trim=max(0,self._loop_end_trim-50)
        elif name=="loop_end_up":   self._loop_end_trim+=50
        elif name=="music_edit": self._editing_music=not self._editing_music
        elif name=="apply": self._apply()
        elif name.startswith("bind_"):
            var=name[5:]; self._waiting_for_key=var
        elif name=="quit_to_menu": self._confirm_quit=True
        elif name=="confirm_quit_yes":
            self.hide()
            if self.game: self.game.request_quit_to_menu=True
        elif name=="confirm_quit_no":
            self._confirm_quit=False

    def _apply(self):
        inp=self._music_input.strip()
        if inp:
            base_dir=os.path.dirname(os.path.abspath(cfg.__file__))
            new_music=inp if os.path.isabs(inp) else os.path.join(base_dir,inp)
        else: new_music=""
        cfg.THEME=self._theme; cfg.MUSIC_VOLUME=self._volume
        cfg.MUSIC_MUTED=self._muted; cfg.CELL_SIZE=self._cell_size
        cfg.MUSIC_FILE=new_music
        cfg.MUSIC_LOOP_START_MS=self._loop_start
        cfg.MUSIC_LOOP_END_TRIM_MS=self._loop_end_trim
        for var,val in self._keys.items(): setattr(cfg,var,val)
        try:
            cfg.save_settings(self._theme,self._volume,self._muted,
                              self._cell_size,new_music,
                              self._loop_start,self._loop_end_trim,
                              {v:self._keys[v] for v,_ in KEYBIND_VARS})
        except Exception as e:
            self._status=f"Save failed: {e}"; self._status_t=time.time(); return
        if self.game:
            self.game.apply_theme(); self.game.apply_music(); self.game.rebuild_window()
            self.hide(); self.game.paused=False
        else:
            setup_music(); self.hide()

    def draw(self):
        if not self.open: return
        self._clickables={}
        W,H=self.screen.get_size()
        dim=pygame.Surface((W,H),pygame.SRCALPHA); dim.fill((0,0,0,185))
        self.screen.blit(dim,(0,0))

        if self._confirm_quit:
            self._draw_confirm_quit(W,H); return

        if self._waiting_for_key is not None:
            self._draw_waiting_for_key(W,H); return

        # Calculate panel height dynamically
        base_h=310
        if self.keybinds_open: base_h+=len(KEYBIND_VARS)*32+16
        if self.advanced: base_h+=140
        if self.game: base_h+=44  # quit to menu button
        pw=520; ph=min(base_h,H-40); px=(W-pw)//2; py=(H-ph)//2
        pygame.draw.rect(self.screen,(22,22,38),(px,py,pw,ph),border_radius=12)
        pygame.draw.rect(self.screen,(80,80,130),(px,py,pw,ph),2,border_radius=12)

        cy=py+20; arr=28; lx=px+250
        self._t("SETTINGS",px+pw//2,cy,self.f_title,(190,190,255),cx=True); cy+=42
        pygame.draw.line(self.screen,(55,55,85),(px+20,cy),(px+pw-20,cy)); cy+=12

        # Theme
        self._t("Theme",px+25,cy+2,self.f_label,(170,170,200))
        self._b(pygame.Rect(lx,cy,arr,26),"<","theme_prev")
        self._t(cfg.THEMES[self._theme]["name"],lx+arr+70,cy+2,self.f_value,(255,240,100),cx=True)
        self._b(pygame.Rect(lx+arr+140,cy,arr,26),">","theme_next"); cy+=38

        # Volume
        self._t("Volume",px+25,cy+2,self.f_label,(170,170,200))
        self._b(pygame.Rect(lx,cy,arr,26),"-","vol_down")
        self._t(f"{int(self._volume*100)}%",lx+arr+55,cy+2,self.f_value,(255,255,255),cx=True)
        self._b(pygame.Rect(lx+arr+110,cy,arr,26),"+","vol_up"); cy+=38

        # Mute
        self._t("Mute",px+25,cy+2,self.f_label,(170,170,200))
        ml="ON" if self._muted else "OFF"; mc=(255,90,90) if self._muted else (80,210,80)
        self._b(pygame.Rect(lx,cy,70,26),ml,"mute_toggle",fg=mc,bg=(50,20,20) if self._muted else (15,45,15)); cy+=38

        # Keybinds toggle
        kl="[-] Keybinds" if self.keybinds_open else "[+] Keybinds"
        self._b(pygame.Rect(px+pw//2-80,cy,160,26),kl,"keybinds_toggle",fg=(160,160,200),bg=(35,35,55)); cy+=36

        if self.keybinds_open:
            pygame.draw.line(self.screen,(45,45,70),(px+20,cy),(px+pw-20,cy)); cy+=8
            for var,label in KEYBIND_VARS:
                self._t(label,px+30,cy+2,self.f_small,(150,155,175))
                current=self._keys.get(var,"?")
                self._b(pygame.Rect(lx-20,cy,130,24),current,f"bind_{var}",fg=(255,220,100),bg=(40,35,15))
                cy+=30
            pygame.draw.line(self.screen,(45,45,70),(px+20,cy),(px+pw-20,cy)); cy+=8

        # Advanced toggle
        al="[-] Advanced" if self.advanced else "[+] Advanced"
        self._b(pygame.Rect(px+pw//2-80,cy,160,26),al,"advanced_toggle",fg=(140,140,180),bg=(30,30,50)); cy+=36

        if self.advanced:
            pygame.draw.line(self.screen,(45,45,70),(px+20,cy),(px+pw-20,cy)); cy+=8
            # Cell size
            self._t("Cell Size (px)",px+30,cy+2,self.f_small,(140,145,165))
            self._b(pygame.Rect(lx,cy,arr,24),"-","cell_down")
            self._t(str(self._cell_size),lx+arr+30,cy+2,self.f_value,(255,255,255),cx=True)
            self._b(pygame.Rect(lx+arr+60,cy,arr,24),"+","cell_up"); cy+=32
            # Music file
            self._t("Music File",px+30,cy+2,self.f_small,(140,145,165))
            box=pygame.Rect(px+170,cy-1,290,26)
            bc=(55,75,55) if self._editing_music else (38,38,52)
            bc2=(90,140,90) if self._editing_music else (65,65,90)
            pygame.draw.rect(self.screen,bc,box,border_radius=4)
            pygame.draw.rect(self.screen,bc2,box,1,border_radius=4)
            disp=self._music_input+("|" if self._editing_music else "")
            ms=self.f_small.render(disp,True,(190,220,190)); self.screen.blit(ms,(box.x+5,box.y+5))
            self._clickables["music_edit"]=box; cy+=32
            # Loop offsets
            self._t("Loop Start (ms)",px+30,cy+2,self.f_small,(140,145,165))
            self._b(pygame.Rect(lx,cy,arr,24),"-","loop_start_down")
            self._t(str(self._loop_start),lx+arr+40,cy+2,self.f_small,(255,255,255),cx=True)
            self._b(pygame.Rect(lx+arr+80,cy,arr,24),"+","loop_start_up"); cy+=30
            self._t("Loop End Trim (ms)",px+30,cy+2,self.f_small,(140,145,165))
            self._b(pygame.Rect(lx,cy,arr,24),"-","loop_end_down")
            self._t(str(self._loop_end_trim),lx+arr+40,cy+2,self.f_small,(255,255,255),cx=True)
            self._b(pygame.Rect(lx+arr+80,cy,arr,24),"+","loop_end_up"); cy+=32
            pygame.draw.line(self.screen,(45,45,70),(px+20,cy),(px+pw-20,cy)); cy+=8

        # Quit to menu (only in-game)
        if self.game:
            self._b(pygame.Rect(px+pw//2-90,cy,180,28),"Quit to Menu","quit_to_menu",fg=(255,100,100),bg=(50,15,15)); cy+=40

        # Apply / Cancel
        btn_y=py+ph-52; bw=120; gap=20; bx=px+(pw-bw*2-gap)//2
        self._b(pygame.Rect(bx,btn_y,bw,36),"Apply","apply",fg=(50,200,80),bg=(18,50,22),big=True)
        self._b(pygame.Rect(bx+bw+gap,btn_y,bw,36),"Cancel","cancel",fg=(200,80,80),bg=(50,18,18),big=True)
        # Close X – use plain X not unicode
        self._b(pygame.Rect(px+pw-32,py+8,24,22),"X","close",fg=(200,100,100),bg=(45,18,18))

        if self._status and time.time()-self._status_t<2.5:
            ss=self.f_small.render(self._status,True,(140,240,140))
            self.screen.blit(ss,(px+(pw-ss.get_width())//2,py+ph+6))

    def _draw_confirm_quit(self, W, H):
        pw,ph=400,180; px=(W-pw)//2; py=(H-ph)//2
        pygame.draw.rect(self.screen,(25,15,15),(px,py,pw,ph),border_radius=10)
        pygame.draw.rect(self.screen,(180,60,60),(px,py,pw,ph),2,border_radius=10)
        self._t("Quit to Main Menu?",px+pw//2,py+20,self.f_title,(255,200,200),cx=True)
        self._t("Current game will be lost.",px+pw//2,py+62,self.f_label,(200,160,160),cx=True)
        bw=110; gap=20; bx=px+(pw-bw*2-gap)//2
        self._b(pygame.Rect(bx,py+100,bw,36),"Yes, Quit","confirm_quit_yes",fg=(255,100,100),bg=(60,15,15),big=True)
        self._b(pygame.Rect(bx+bw+gap,py+100,bw,36),"Cancel","confirm_quit_no",fg=(100,200,100),bg=(15,50,15),big=True)

    def _draw_waiting_for_key(self, W, H):
        pw,ph=380,140; px=(W-pw)//2; py=(H-ph)//2
        pygame.draw.rect(self.screen,(15,20,35),(px,py,pw,ph),border_radius=10)
        pygame.draw.rect(self.screen,(80,80,180),(px,py,pw,ph),2,border_radius=10)
        label=next((l for v,l in KEYBIND_VARS if v==self._waiting_for_key),"?")
        self._t(f"Press a key for:",px+pw//2,py+25,self.f_label,(180,180,220),cx=True)
        self._t(label,px+pw//2,py+55,self.f_title,(255,240,120),cx=True)
        self._t("ESC to cancel",px+pw//2,py+100,self.f_small,(100,100,130),cx=True)

    def _t(self, text, x, y, font, color, cx=False):
        surf=font.render(text,True,color)
        self.screen.blit(surf,(x-surf.get_width()//2 if cx else x,y))

    def _b(self, rect, label, action, fg=(200,200,220), bg=(38,38,58), big=False):
        pygame.draw.rect(self.screen,bg,rect,border_radius=5)
        pygame.draw.rect(self.screen,fg,rect,1,border_radius=5)
        f=self.f_btn if big else self.f_small
        surf=f.render(label,True,fg)
        self.screen.blit(surf,(rect.centerx-surf.get_width()//2,rect.centery-surf.get_height()//2))
        self._clickables[action]=rect

# ===========================================================================
#  Tetris game
# ===========================================================================
class Tetris:
    def __init__(self, screen):
        self.screen=screen; self.clock=pygame.time.Clock()
        self.theme=active_theme(); self._build_fonts(); self._calc_layout()
        self.music_loaded=setup_music()
        self.settings=SettingsScreen(screen, self)
        self.request_quit_to_menu=False
        self.reset()

    def _build_fonts(self):
        t=self.theme
        self.font_large=make_font(*t["font_large"],bold=True)
        self.font_medium=make_font(*t["font_panel"])
        self.font_small=make_font(*t["font_label"])

    def _calc_layout(self):
        s=cfg.CELL_SIZE; W,H=window_size()
        self.grid_origin_x=(W-cfg.GRID_COLS*s)//2; self.grid_origin_y=(H-cfg.GRID_ROWS*s)//2
        self.panel_left_x=self.grid_origin_x-160; self.panel_right_x=self.grid_origin_x+cfg.GRID_COLS*s+20

    def rebuild_window(self):
        W,H=window_size()
        self.screen=pygame.display.set_mode((W,H),pygame.RESIZABLE)
        self.settings.screen=self.screen; self._calc_layout()
        self.theme=active_theme(); self._build_fonts()

    def apply_theme(self):
        self.theme=active_theme(); self._build_fonts()
        # Refresh current piece colour
        if hasattr(self,"current"): self.current.refresh_color(self.theme)
        # Refresh next pieces
        if hasattr(self,"next_pieces"):
            for p in self.next_pieces: p.refresh_color(self.theme)

    def apply_music(self):
        self.music_loaded=setup_music()

    def reset(self):
        self.theme=active_theme(); self.board=Board(); self.bag=Bag()
        self.score=0; self.lines=0; self.level=1
        self.game_over=False; self.paused=False
        self.request_quit_to_menu=False
        self.held_type=None; self.hold_used=False
        self.next_pieces=[self.bag.next(self.theme) for _ in range(5)]
        self.current=self._spawn(); self.last_move_rotation=False
        self.gravity_timer=time.time(); self.lock_timer=None; self.lock_resets=0
        self.soft_dropping=False; self.soft_drop_timer=time.time()
        self.b2b_active=False; self.popup_text=""; self.popup_timer=0
        self.das_key=None; self.das_timer=0; self.das_charged=False
        self.DAS_DELAY=170; self.ARR_INTERVAL=50

    def _spawn(self):
        p=self.next_pieces.pop(0); self.next_pieces.append(self.bag.next(self.theme))
        p.row=1; p.col=cfg.GRID_COLS//2-1; return p

    def _try_move(self, dr, dc):
        nc=self.current.cells(self.current.row+dr,self.current.col+dc)
        if self.board.valid(nc):
            self.current.row+=dr; self.current.col+=dc
            if dc!=0: self.last_move_rotation=False; self._reset_lock()
            return True
        return False

    def _try_rotate(self, direction=1):
        p=self.current; old_rot=p.rotation; new_rot=(old_rot+direction)%4
        for dc,dr in get_kick_table(p.type).get((old_rot,new_rot),[(0,0)]):
            if self.board.valid(p.cells(p.row+dr,p.col+dc,new_rot)):
                p.rotation=new_rot; p.row+=dr; p.col+=dc
                self.last_move_rotation=True; self._reset_lock(); return True
        return False

    def _reset_lock(self):
        if self.lock_timer is not None and self.lock_resets<cfg.LOCK_RESETS_MAX:
            self.lock_timer=time.time(); self.lock_resets+=1

    def _on_ground(self): return not self.board.valid(self.current.cells(self.current.row+1,self.current.col))

    def _ghost_row(self):
        r=self.current.row
        while self.board.valid(self.current.cells(r+1,self.current.col)): r+=1
        return r

    def _hard_drop(self):
        dist=0
        while self._try_move(1,0): dist+=1
        self.score+=dist*cfg.SCORE_HARD_DROP_PER_ROW; self._lock_piece()

    def _lock_piece(self):
        tspin=detect_tspin(self.board,self.current,self.last_move_rotation)
        self.board.lock(self.current); cleared=self.board.clear_lines()
        self._apply_score(cleared,tspin)
        self.lines+=cleared; self.level=max(self.level,self.lines//cfg.LINES_PER_LEVEL+1)
        self.hold_used=False; self.current=self._spawn(); self.last_move_rotation=False
        if not self.board.valid(self.current.cells()):
            self.game_over=True; save_highscore(self.score)
        self.lock_timer=None; self.lock_resets=0

    def _apply_score(self, cleared, tspin):
        base=0; label=""; is_special=False
        if tspin=="tspin":
            is_special=True
            data=[(cfg.SCORE_TSPIN,"T-Spin!"),(cfg.SCORE_TSPIN_SINGLE,"T-Spin Single!"),
                  (cfg.SCORE_TSPIN_DOUBLE,"T-Spin Double!"),(cfg.SCORE_TSPIN_TRIPLE,"T-Spin Triple!")]
            base,label=data[min(cleared,3)]
        else:
            if cleared==1: base,label=cfg.SCORE_SINGLE,"Single"
            elif cleared==2: base,label=cfg.SCORE_DOUBLE,"Double"
            elif cleared==3: base,label=cfg.SCORE_TRIPLE,"Triple"
            elif cleared>=4: base,label,is_special=cfg.SCORE_TETRIS,"TETRIS!",True
        if base>0:
            if is_special and self.b2b_active:
                base+=int(base*cfg.SCORE_B2B_BONUS_FACTOR); label="B2B "+label
            self.b2b_active=is_special; self.score+=base*self.level
            self.popup_text=label; self.popup_timer=time.time()

    def _hold(self):
        if self.hold_used: return
        if self.held_type is None:
            self.held_type=self.current.type; self.current=self._spawn()
        else:
            self.held_type,nt=self.current.type,self.held_type
            self.current=Piece(nt,self.theme)
            # Fix: immediately check theme colour on spawn from hold
            self.current.refresh_color(self.theme)
        self.hold_used=True; self.last_move_rotation=False

    def update(self, dt_ms):
        if self.game_over or self.paused: return
        now=time.time()
        if self.das_key:
            if not self.das_charged:
                self.das_timer+=dt_ms
                if self.das_timer>=self.DAS_DELAY: self.das_charged=True; self.das_timer=0
            else:
                self.das_timer+=dt_ms
                while self.das_timer>=self.ARR_INTERVAL:
                    self.das_timer-=self.ARR_INTERVAL
                    if self.das_key=="left": self._try_move(0,-1)
                    elif self.das_key=="right": self._try_move(0,1)
        if self.soft_dropping:
            if now-self.soft_drop_timer>=cfg.SOFT_DROP_INTERVAL:
                self.soft_drop_timer=now
                if self._try_move(1,0): self.score+=cfg.SCORE_SOFT_DROP_PER_ROW
        if not self.soft_dropping:
            if now-self.gravity_timer>=gravity_interval(self.level):
                self.gravity_timer=now; self._try_move(1,0)
        if self._on_ground():
            if self.lock_timer is None: self.lock_timer=now; self.lock_resets=0
            elif now-self.lock_timer>=cfg.LOCK_DELAY: self._lock_piece()
        else: self.lock_timer=None

    def handle_event(self, event):
        if self.settings.handle_event(event): return None
        if event.type==pygame.USEREVENT+1: handle_music_end(); return None
        if event.type==pygame.KEYDOWN:
            k=pygame.key.name(event.key)
            if self.game_over: return "menu"
            if k=="escape":
                self.paused=not self.paused
                if self.paused: self.settings.show()
                else: self.settings.hide()
                return None
            if self.paused: return None
            if k==cfg.KEY_MINIMIZE:
                pygame.display.iconify(); self.paused=True; self.settings.show()
                return None
            if k==cfg.KEY_MOVE_LEFT:
                self._try_move(0,-1); self.das_key="left"; self.das_timer=0; self.das_charged=False
            elif k==cfg.KEY_MOVE_RIGHT:
                self._try_move(0,1); self.das_key="right"; self.das_timer=0; self.das_charged=False
            elif k==cfg.KEY_ROTATE_CW: self._try_rotate(1)
            elif k==cfg.KEY_SOFT_DROP: self.soft_dropping=True; self.soft_drop_timer=time.time()
            elif k==cfg.KEY_HARD_DROP: self._hard_drop()
            elif k==cfg.KEY_HOLD: self._hold()
            elif k==cfg.KEY_MUTE: self._toggle_mute()
            elif k=="up": self._change_volume(0.05)
            elif k=="down": self._change_volume(-0.05)
        elif event.type==pygame.KEYUP:
            k=pygame.key.name(event.key)
            if k==cfg.KEY_MOVE_LEFT and self.das_key=="left": self.das_key=None
            if k==cfg.KEY_MOVE_RIGHT and self.das_key=="right": self.das_key=None
            if k==cfg.KEY_SOFT_DROP: self.soft_dropping=False
        elif event.type==pygame.USEREVENT+1:
            handle_music_end()
        if self.request_quit_to_menu: return "menu"
        return None

    def _toggle_mute(self):
        cfg.MUSIC_MUTED=not cfg.MUSIC_MUTED
        pygame.mixer.music.set_volume(0 if cfg.MUSIC_MUTED else cfg.MUSIC_VOLUME)

    def _change_volume(self, delta):
        cfg.MUSIC_VOLUME=max(0.0,min(1.0,round(cfg.MUSIC_VOLUME+delta,2)))
        if not cfg.MUSIC_MUTED: pygame.mixer.music.set_volume(cfg.MUSIC_VOLUME)

    def draw(self):
        t=self.theme; ox=self.grid_origin_x; oy=self.grid_origin_y
        nes=t.get("nes_layout",False)
        self.screen.fill(t["panel_bg"])
        draw_grid(self.screen,self.board,ox,oy,t)
        gr=self._ghost_row()
        draw_ghost(self.screen,self.current.cells(gr,self.current.col),ox,oy,
                   self.current.color,t["ghost_alpha"],outline_only=t.get("calc_outline",False))
        for r,c in self.current.cells():
            if r>=0: draw_cell(self.screen,self.current.color,r,c,ox,oy,
                               bevel=t.get("use_bevel",True),dither=t.get("retro_dither",False))
        if t.get("scanlines"): draw_scanlines(self.screen,ox,oy)
        s=cfg.CELL_SIZE
        if nes: draw_nes_brick_border(self.screen,ox,oy,t)
        elif t.get("retro_border"): draw_retro_border(self.screen,ox,oy,t)
        else: pygame.draw.rect(self.screen,t["border_color"],(ox,oy,cfg.GRID_COLS*s,cfg.GRID_ROWS*s),2)
        if nes: self._draw_panels_nes()
        else: self._draw_panels_default()
        self._draw_hud()
        if self.paused and not self.settings.open:
            self._draw_overlay("PAUSED","ESC to resume / settings")
        if self.game_over:
            self._draw_overlay("GAME OVER",f"Score: {self.score}   Any key for menu")
        self.settings.draw()
        pygame.display.flip()

    def _draw_panels_default(self):
        t=self.theme; ox=self.grid_origin_x; oy=self.grid_origin_y
        rx=self.panel_right_x; lx=self.panel_left_x; s=cfg.CELL_SIZE
        panel_w=150; panel_cx_l=lx+panel_w//2; panel_cx_r=rx+panel_w//2

        # RIGHT: NEXT
        self._label("NEXT",panel_cx_r,oy+8)
        for i,p in enumerate(self.next_pieces[:5]):
            mini_piece(self.screen,p.type,rx+panel_w//2,oy+52+i*54,t)

        # LEFT: HOLD
        self._label("HOLD",panel_cx_l,oy+8)
        if self.held_type:
            col=t["piece_colors"][self.held_type]
            if self.hold_used: col=tuple(v//2 for v in col)
            cb=PIECES[self.held_type][0]
            rows_=[r for r,c in cb]; cols_=[c for r,c in cb]
            min_r=min(rows_); min_c=min(cols_); cs=20
            bx=lx+panel_w//2-(max(cols_)-min_c+1)*cs//2
            by=oy+52-(max(rows_)-min_r+1)*cs//2
            for dr,dc in cb:
                x=bx+(dc-min_c)*cs; y=by+(dr-min_r)*cs
                pygame.draw.rect(self.screen,col,(x+1,y+1,cs-2,cs-2))
                if t.get("use_bevel"):
                    lighter=tuple(min(255,v+40) for v in col)
                    pygame.draw.line(self.screen,lighter,(x+1,y+1),(x+cs-2,y+1),2)
                    pygame.draw.line(self.screen,lighter,(x+1,y+1),(x+1,y+cs-2),2)

        sy=oy+115
        for lbl,val,dy in [("SCORE",str(self.score),0),("LEVEL",str(self.level),58),("LINES",str(self.lines),116)]:
            self._label(lbl,panel_cx_l,sy+dy); self._value(val,panel_cx_l,sy+dy+20)

        my=oy+cfg.GRID_ROWS*s-75
        if self.music_loaded:
            status="MUTED" if cfg.MUSIC_MUTED else f"VOL {int(cfg.MUSIC_VOLUME*100)}%"
            self._label(status,panel_cx_l,my); self._small("^ v vol  M mute",panel_cx_l,my+17)
        else: self._small("No music",panel_cx_l,my)

        if self.popup_text and time.time()-self.popup_timer<1.5:
            alpha=max(0,255-int((time.time()-self.popup_timer)/1.5*255))
            surf=self.font_large.render(self.popup_text,True,t["popup_color"])
            surf.set_alpha(alpha)
            px=ox+(cfg.GRID_COLS*s-surf.get_width())//2
            py=oy+cfg.GRID_ROWS*s//2-20; self.screen.blit(surf,(px,py))

        hints=[f"{cfg.KEY_MOVE_LEFT.upper()}/{cfg.KEY_MOVE_RIGHT.upper()} move",
               f"{cfg.KEY_ROTATE_CW.upper()} rotate",
               f"{cfg.KEY_SOFT_DROP.upper()} soft drop",
               "SPC hard drop",f"{cfg.KEY_HOLD.upper()} hold","ESC settings"]
        hy=oy+cfg.GRID_ROWS*s-len(hints)*15
        for i,h in enumerate(hints): self._small(h,rx+panel_w//2,hy+i*15)

    def _draw_panels_nes(self):
        t=self.theme; ox=self.grid_origin_x; oy=self.grid_origin_y
        s=cfg.CELL_SIZE; gw=cfg.GRID_COLS*s; gh=cfg.GRID_ROWS*s
        W=self.screen.get_width()
        WHITE=(255,255,255); YELLOW=(255,255,0); GREY=(160,160,160)
        lx=self.panel_left_x; rx=self.panel_right_x
        panel_w=150; panel_cx_l=lx+panel_w//2; panel_cx_r=rx+panel_w//2

        # LINES top-centre
        lines_str=f"LINES-{self.lines:03d}"
        surf=self.font_medium.render(lines_str,True,WHITE)
        self.screen.blit(surf,(ox+(gw-surf.get_width())//2,oy-26))

        # Left panel
        render_left(self.screen,"TOP",self.font_small,GREY,lx+8,oy+8)
        top=load_highscores(); top_val=top[0] if top else 0
        render_left(self.screen,f"{top_val:>7}",self.font_medium,WHITE,lx+8,oy+24)
        render_left(self.screen,"SCORE",self.font_small,GREY,lx+8,oy+60)
        render_left(self.screen,f"{self.score:>7}",self.font_medium,WHITE,lx+8,oy+76)
        pygame.draw.rect(self.screen,(0,0,80),(lx+5,oy+115,panel_w-10,70),border_radius=4)
        render_left(self.screen,"LEVEL",self.font_small,GREY,lx+12,oy+120)
        render_left(self.screen,f"{self.level}",self.font_large,YELLOW,lx+12,oy+136)

        # Right panel
        render_left(self.screen,"NEXT",self.font_small,GREY,rx+8,oy+8)
        mini_piece(self.screen,self.next_pieces[0].type,rx+panel_w//2,oy+60,t,cell_size=s-2)
        pygame.draw.rect(self.screen,(0,0,80),(rx+5,oy+115,panel_w-10,170),border_radius=4)
        render_left(self.screen,"STATS",self.font_small,GREY,rx+12,oy+120)
        for i,pt in enumerate(PIECES.keys()):
            col=t["piece_colors"][pt]
            pygame.draw.rect(self.screen,col,(rx+12,oy+140+i*22,10,10))
            cnt=sum(1 for p in self.next_pieces if p.type==pt)
            render_left(self.screen,f"{pt}:{cnt}",self.font_small,WHITE,rx+28,oy+138+i*22)

        if self.popup_text and time.time()-self.popup_timer<1.5:
            alpha=max(0,255-int((time.time()-self.popup_timer)/1.5*255))
            surf=self.font_large.render(self.popup_text,True,YELLOW)
            surf.set_alpha(alpha)
            self.screen.blit(surf,(ox+(gw-surf.get_width())//2,oy+gh//2-20))

    def _draw_hud(self):
        if self.theme.get("nes_layout"): return
        scores=load_highscores()
        if scores:
            txt="  HI: "+"  ".join(str(s) for s in scores[:3])
            surf=self.font_small.render(txt,True,self.theme["hud_text"])
            self.screen.blit(surf,(self.grid_origin_x,self.grid_origin_y-22))

    def _draw_overlay(self, title, subtitle):
        ov=pygame.Surface(self.screen.get_size(),pygame.SRCALPHA)
        ov.fill(self.theme["overlay_bg"]); self.screen.blit(ov,(0,0))
        cx=self.screen.get_width()//2; cy=self.screen.get_height()//2
        t_=self.font_large.render(title,True,self.theme["overlay_title"])
        s_=self.font_medium.render(subtitle,True,self.theme["overlay_sub"])
        self.screen.blit(t_,(cx-t_.get_width()//2,cy-30))
        self.screen.blit(s_,(cx-s_.get_width()//2,cy+10))

    def _label(self,text,cx,y):
        surf=self.font_small.render(text,True,self.theme["panel_fg"])
        self.screen.blit(surf,(cx-surf.get_width()//2,y))
    def _value(self,text,cx,y):
        surf=self.font_medium.render(text,True,self.theme["panel_value"])
        self.screen.blit(surf,(cx-surf.get_width()//2,y))
    def _small(self,text,cx,y):
        surf=self.font_small.render(text,True,self.theme["panel_dim"])
        self.screen.blit(surf,(cx-surf.get_width()//2,y))

# ===========================================================================
#  App controller
# ===========================================================================
class App:
    STATE_MENU="menu"; STATE_GAME="game"; STATE_SCORES="scores"

    def __init__(self):
        pygame.init(); pygame.mixer.init()
        W,H=window_size()
        self.screen=pygame.display.set_mode((W,H),pygame.RESIZABLE)
        pygame.display.set_caption(cfg.WINDOW_TITLE)
        self.clock=pygame.time.Clock(); self.state=self.STATE_MENU
        self.menu=MainMenu(self.screen); self.game=None
        self.scores=HighScoresScreen(self.screen)
        self.menu_settings=SettingsScreen(self.screen,game_ref=None)
        setup_music()

    def run(self):
        while True:
            dt=self.clock.tick(cfg.FPS)
            for event in pygame.event.get():
                if event.type==pygame.QUIT: pygame.quit(); sys.exit()
                if event.type==_music_end_event: handle_music_end()
                self._handle_event(event,dt)
            self._update(dt); self._draw(dt)

    def _handle_event(self, event, dt):
        if self.state==self.STATE_MENU:
            if self.menu_settings.open:
                self.menu_settings.handle_event(event)
                if not self.menu_settings.open:
                    W,H=window_size()
                    self.screen=pygame.display.set_mode((W,H),pygame.RESIZABLE)
                    self.menu_settings.screen=self.screen
                    self.menu.screen=self.screen; self.scores.screen=self.screen
            else:
                action=self.menu.handle_event(event)
                if action=="PLAY": self._start_game()
                elif action=="SETTINGS": self.menu_settings.screen=self.screen; self.menu_settings.show()
                elif action=="HIGH SCORES": self.state=self.STATE_SCORES
                elif action=="QUIT": pygame.quit(); sys.exit()
        elif self.state==self.STATE_GAME:
            result=self.game.handle_event(event)
            if result=="menu": self.state=self.STATE_MENU
        elif self.state==self.STATE_SCORES:
            if self.scores.handle_event(event): self.state=self.STATE_MENU

    def _start_game(self):
        if self.game is None:
            self.game=Tetris(self.screen)
        else:
            self.game.screen=self.screen; self.game.settings.screen=self.screen
            self.game.reset()
        self.state=self.STATE_GAME

    def _update(self, dt):
        if self.state==self.STATE_GAME and self.game: self.game.update(dt)

    def _draw(self, dt):
        if self.state==self.STATE_MENU:
            self.menu.draw(dt); self.menu_settings.draw()
        elif self.state==self.STATE_GAME and self.game:
            self.game.draw()
        elif self.state==self.STATE_SCORES:
            self.scores.draw()
        pygame.display.flip()

if __name__=="__main__":
    App().run()