"""tetris.py – main game file. Config in tetris_config.py"""
import pygame, sys, os, random, time, hashlib, base64, json, re
import tetris_config as cfg

# ---------------------------------------------------------------------------
#  Piece data  (coordinates are [row_offset, col_offset] from pivot)
# ---------------------------------------------------------------------------
PIECES = {
    "I": [[(0,-1),(0,0),(0,1),(0,2)],[(-1,1),(0,1),(1,1),(2,1)],
          [(1,-1),(1,0),(1,1),(1,2)],[(-1,0),(0,0),(1,0),(2,0)]],
    "O": [[(0,0),(0,1),(1,0),(1,1)]]*4,
    "T": [[(0,-1),(0,0),(0,1),(-1,0)],[(-1,0),(0,0),(1,0),(0,1)],
          [(0,-1),(0,0),(0,1),(1,0)],[(-1,0),(0,0),(1,0),(0,-1)]],
    "S": [[(0,-1),(0,0),(-1,0),(-1,1)],[(-1,0),(0,0),(0,1),(1,1)],
          [(1,-1),(1,0),(0,0),(0,1)],[(-1,-1),(0,-1),(0,0),(1,0)]],
    "Z": [[(-1,-1),(-1,0),(0,0),(0,1)],[(-1,1),(0,0),(0,1),(1,0)],
          [(1,-1),(1,0),(0,0),(0,1)],[(-1,0),(0,-1),(0,0),(1,-1)]],
    "J": [[(0,-1),(0,0),(0,1),(-1,-1)],[(-1,0),(0,0),(1,0),(-1,1)],
          [(0,-1),(0,0),(0,1),(1,1)],[(-1,0),(0,0),(1,0),(1,-1)]],
    "L": [[(0,-1),(0,0),(0,1),(-1,1)],[(-1,0),(0,0),(1,0),(1,1)],
          [(0,-1),(0,0),(0,1),(1,-1)],[(-1,0),(0,0),(1,0),(-1,-1)]],
}

# SRS wall-kick tables  {(from_rot, to_rot): [(col_offset, row_offset), ...]}
KICKS_JLSTZ = {
    (0,1):[(0,0),(-1,0),(-1, 1),(0,-2),(-1,-2)],
    (1,0):[(0,0),( 1,0),( 1,-1),(0, 2),( 1, 2)],
    (1,2):[(0,0),( 1,0),( 1,-1),(0, 2),( 1, 2)],
    (2,1):[(0,0),(-1,0),(-1, 1),(0,-2),(-1,-2)],
    (2,3):[(0,0),( 1,0),( 1, 1),(0,-2),( 1,-2)],
    (3,2):[(0,0),(-1,0),(-1,-1),(0, 2),(-1, 2)],
    (3,0):[(0,0),(-1,0),(-1,-1),(0, 2),(-1, 2)],
    (0,3):[(0,0),( 1,0),( 1, 1),(0,-2),( 1,-2)],
}
KICKS_I = {
    (0,1):[(0,0),(-2,0),( 1,0),(-2,-1),( 1, 2)],
    (1,0):[(0,0),( 2,0),(-1,0),( 2, 1),(-1,-2)],
    (1,2):[(0,0),(-1,0),( 2,0),(-1, 2),( 2,-1)],
    (2,1):[(0,0),( 1,0),(-2,0),( 1,-2),(-2, 1)],
    (2,3):[(0,0),( 2,0),(-1,0),( 2, 1),(-1,-2)],
    (3,2):[(0,0),(-2,0),( 1,0),(-2,-1),( 1, 2)],
    (3,0):[(0,0),( 1,0),(-2,0),( 1,-2),(-2, 1)],
    (0,3):[(0,0),(-1,0),( 2,0),(-1, 2),( 2,-1)],
}
def get_kicks(pt): return KICKS_I if pt == "I" else KICKS_JLSTZ

# T-piece facing directions: which row offset points "forward"
# rotation 0=North,1=East,2=South,3=West
# Front corners (the two corners the stem points toward) per rotation
T_FRONT = {0:(-1,-1,-1,1), 1:(-1,1,1,1), 2:(1,-1,1,1), 3:(-1,-1,1,-1)}
# Encoded as (dr1,dc1,dr2,dc2) for the two front corners relative to pivot

# ---------------------------------------------------------------------------
#  Helpers
# ---------------------------------------------------------------------------
def gravity_interval(level): return cfg.GRAVITY_TABLE.get(level, 0.017)

def shorten(n):
    if n >= 1_000_000_000: return f"{n/1_000_000_000:.1f}B"
    if n >= 1_000_000:     return f"{n/1_000_000:.1f}M"
    if n >= 1_000:         return f"{n/1_000:.1f}K"
    return str(n)

def make_font(family, size, bold=False):
    return pygame.font.SysFont(family, size, bold=bold)

def blit_centered(surface, text, font, color, cx, y):
    s = font.render(text, True, color); surface.blit(s, (cx - s.get_width()//2, y))
def blit_left(surface, text, font, color, x, y):
    s = font.render(text, True, color); surface.blit(s, (x, y))

# ---------------------------------------------------------------------------
#  Tamper-resistant file helpers  (shared by highscores + statistics)
# ---------------------------------------------------------------------------
def _salt():
    a="t3tr"; b=bytes([0x31,0x73]).decode()
    c=str(cfg.GRID_COLS*cfg.GRID_ROWS*7+13)
    d="".join(chr(x) for x in [95,115,52,108,116])
    return hashlib.sha256((a+b+c+d).encode()).hexdigest()

def _sign(payload_str):
    return hashlib.sha256((_salt()+payload_str+_salt()).encode()).hexdigest()

def _write_secure(path, data_dict):
    payload = json.dumps(data_dict, sort_keys=True)
    sig     = _sign(payload)
    blob    = base64.b64encode(f"{payload}|||{sig}".encode())
    with open(path, "wb") as f: f.write(blob)

def _read_secure(path):
    if not os.path.exists(path): return None
    try:
        raw  = base64.b64decode(open(path,"rb").read()).decode()
        payload, sig = raw.rsplit("|||", 1)
        if _sign(payload) != sig: return None
        return json.loads(payload)
    except: return None

# ---------------------------------------------------------------------------
#  High scores
# ---------------------------------------------------------------------------
def load_highscores():
    data = _read_secure(cfg.HIGHSCORE_FILE)
    if not data or "scores" not in data: return []
    return sorted([int(x) for x in data["scores"]], reverse=True)[:cfg.HIGHSCORE_COUNT]

def save_highscore(score):
    scores = load_highscores()
    scores.append(score)
    scores = sorted(scores, reverse=True)[:cfg.HIGHSCORE_COUNT]
    _write_secure(cfg.HIGHSCORE_FILE, {"scores": scores})

# ---------------------------------------------------------------------------
#  Statistics
# ---------------------------------------------------------------------------
PIECE_TYPES = ["I","O","T","S","Z","J","L"]

_STAT_DEFAULTS = {
    "total_lines": 0, "total_score": 0, "total_blocks": 0,
    "total_by_type": {p:0 for p in PIECE_TYPES},
    "best_score": 0, "best_lines": 0, "best_level": 0, "best_blocks": 0,
    "best_by_type": {p:0 for p in PIECE_TYPES},
}

def load_stats():
    data = _read_secure(cfg.STATISTICS_FILE)
    if not data:
        import copy; return copy.deepcopy(_STAT_DEFAULTS)
    # fill any missing keys
    import copy; base = copy.deepcopy(_STAT_DEFAULTS); base.update(data)
    for p in PIECE_TYPES:
        base["total_by_type"].setdefault(p, 0)
        base["best_by_type"].setdefault(p, 0)
    return base

def save_stats(stats): _write_secure(cfg.STATISTICS_FILE, stats)

def record_game(score, lines, level, blocks, by_type):
    """Call at game-over to update persistent statistics."""
    s = load_stats()
    s["total_lines"]  += lines
    s["total_score"]  += score
    s["total_blocks"] += blocks
    for p in PIECE_TYPES:
        s["total_by_type"][p] = s["total_by_type"].get(p,0) + by_type.get(p,0)
    s["best_score"]  = max(s["best_score"],  score)
    s["best_lines"]  = max(s["best_lines"],  lines)
    s["best_level"]  = max(s["best_level"],  level)
    s["best_blocks"] = max(s["best_blocks"], blocks)
    for p in PIECE_TYPES:
        s["best_by_type"][p] = max(s["best_by_type"].get(p,0), by_type.get(p,0))
    save_stats(s)

# ---------------------------------------------------------------------------
#  Music
# ---------------------------------------------------------------------------
MUSIC_END_EVENT = pygame.USEREVENT + 1

def setup_music():
    mf = cfg.MUSIC_FILE
    if mf and os.path.exists(mf):
        try:
            pygame.mixer.music.load(mf)
            pygame.mixer.music.set_volume(0 if cfg.MUSIC_MUTED else cfg.MUSIC_VOLUME)
            pygame.mixer.music.play(0, start=max(0, cfg.MUSIC_LOOP_START_MS)/1000.0)
            pygame.mixer.music.set_endevent(MUSIC_END_EVENT)
            return True
        except: pass
    return False

def handle_music_end():
    mf = cfg.MUSIC_FILE
    if mf and os.path.exists(mf):
        try: pygame.mixer.music.play(0, start=max(0, cfg.MUSIC_LOOP_START_MS)/1000.0)
        except: pass

# ---------------------------------------------------------------------------
#  Drawing helpers
# ---------------------------------------------------------------------------
def draw_cell(surf, color, row, col, ox, oy, size, bevel=True, dither=False):
    x = ox + col*size; y = oy + row*size
    pygame.draw.rect(surf, color, (x+1, y+1, size-2, size-2))
    if bevel:
        lt = tuple(min(255,v+60) for v in color)
        pygame.draw.line(surf, lt, (x+1,y+1), (x+size-2,y+1), 2)
        pygame.draw.line(surf, lt, (x+1,y+1), (x+1,y+size-2), 2)
    if dither:
        dot = max(3, size//5); lt = tuple(min(255,v+90) for v in color)
        pygame.draw.rect(surf, lt, (x+3,y+3,dot,dot))

def draw_cell_outline(surf, color, row, col, ox, oy, size):
    x = ox+col*size; y = oy+row*size
    pygame.draw.rect(surf, color, (x+2,y+2,size-4,size-4), 1)

def draw_ghost(surf, cells, ox, oy, color, alpha, outline_only, size):
    if outline_only:
        for r,c in cells:
            if r >= 0: draw_cell_outline(surf, color, r, c, ox, oy, size)
        return
    if alpha == 0: return
    gs = pygame.Surface((size-2,size-2), pygame.SRCALPHA)
    r,g,b = color; gs.fill((r,g,b,alpha))
    for row,col in cells:
        if row >= 0:
            surf.blit(gs, (ox+col*size+1, oy+row*size+1))
            pygame.draw.rect(surf, color, (ox+col*size+1,oy+row*size+1,size-2,size-2),1)

def draw_grid(surf, board, ox, oy, size, theme):
    bevel  = theme.get("use_bevel",True)
    dither = theme.get("retro_dither",False)
    W = cfg.GRID_COLS*size; H = cfg.GRID_ROWS*size
    pygame.draw.rect(surf, theme["grid_bg"], (ox, oy, W, H))
    for r in range(cfg.GRID_ROWS+1):
        pygame.draw.line(surf, theme["grid_line"], (ox,oy+r*size), (ox+W,oy+r*size))
    for c in range(cfg.GRID_COLS+1):
        pygame.draw.line(surf, theme["grid_line"], (ox+c*size,oy), (ox+c*size,oy+H))
    for r in range(cfg.GRID_ROWS):
        for c in range(cfg.GRID_COLS):
            ri = board._ri(r)   # offset past hidden spawn rows
            if 0 <= ri < TOTAL_ROWS:
                pt = board.grid[ri][c]
                if pt:
                    col = theme["piece_colors"].get(pt,(200,200,200))
                    draw_cell(surf,col,r,c,ox,oy,size,bevel=bevel,dither=dither)

def draw_scanlines(surf, ox, oy, size):
    W=cfg.GRID_COLS*size; H=cfg.GRID_ROWS*size
    sl=pygame.Surface((W,H),pygame.SRCALPHA)
    for y in range(0,H,2): pygame.draw.line(sl,(0,0,0,70),(0,y),(W,y))
    surf.blit(sl,(ox,oy))

def mini_piece(surf, piece_type, cx, cy, theme, cell_size, outline=False):
    cells  = PIECES[piece_type][0]
    rows_  = [r for r,c in cells]; cols_  = [c for r,c in cells]
    min_r  = min(rows_); min_c = min(cols_)
    ox     = cx - (max(cols_)-min_c+1)*cell_size//2
    oy_    = cy - (max(rows_)-min_r+1)*cell_size//2
    color  = theme["piece_colors"][piece_type]
    bevel  = theme.get("use_bevel",True)
    dither = theme.get("retro_dither",False)
    use_ol = outline or theme.get("calc_outline",False)
    for dr,dc in cells:
        x=ox+(dc-min_c)*cell_size; y=oy_+(dr-min_r)*cell_size
        if use_ol:
            pygame.draw.rect(surf, color, (x+2,y+2,cell_size-4,cell_size-4),1)
        else:
            pygame.draw.rect(surf, color, (x+1,y+1,cell_size-2,cell_size-2))
            if bevel:
                lt=tuple(min(255,v+60) for v in color)
                pygame.draw.line(surf,lt,(x+1,y+1),(x+cell_size-2,y+1),2)
                pygame.draw.line(surf,lt,(x+1,y+1),(x+1,y+cell_size-2),2)
            if dither:
                dot=max(2,cell_size//5); lt=tuple(min(255,v+90) for v in color)
                pygame.draw.rect(surf,lt,(x+2,y+2,dot,dot))

# ---------------------------------------------------------------------------
#  Layout  – fixed pixel offsets inside a centred container.
#  The container = piece-preview strip + grid, centred in the window.
#  Panel columns are fixed distances left/right of the grid.
# ---------------------------------------------------------------------------
PANEL_LEFT_OFFSET  = 110   # px from grid left edge to left-panel centre
PANEL_RIGHT_OFFSET = 110   # px from grid right edge to right-panel centre
PREVIEW_H_CELLS    = 2.5   # height of piece-preview strip above grid

def calc_layout(W, H):
    s  = cfg.CELL_SIZE
    gw = cfg.GRID_COLS * s
    gh = cfg.GRID_ROWS * s
    preview_h = int(s * PREVIEW_H_CELLS)
    total_h   = gh + preview_h
    oy = (H - total_h) // 2 + preview_h   # top of visible grid
    ox = (W - gw) // 2                    # left of grid
    return {
        "ox": ox, "oy": oy, "s": s,
        "gw": gw, "gh": gh,
        "preview_h": preview_h,
        "panel_left_cx":  ox - PANEL_LEFT_OFFSET,
        "panel_right_cx": ox + gw + PANEL_RIGHT_OFFSET,
    }

# ---------------------------------------------------------------------------
#  T-spin detection  (proper Tetris Guideline implementation)
# ---------------------------------------------------------------------------
def detect_tspin(board, piece, last_was_rotation):
    """
    Returns "tspin", "tspin_mini", or "none".
    Rules (Guideline):
      - Piece must be T
      - Last action must have been a rotation
      - 3-corner rule: at least 3 of the 4 diagonal corners must be occupied
        (wall counts as occupied)
      - Mini vs full: if the 2 FRONT corners are both occupied → full T-spin
        otherwise (only back corners + 1 front) → mini T-spin
    """
    if piece.type != "T" or not last_was_rotation:
        return "none"

    r, c = piece.row, piece.col
    rot  = piece.rotation % 4

    # All 4 diagonal corners
    corners = [(-1,-1),(-1,1),(1,-1),(1,1)]

    def occupied(dr, dc):
        cr, cc = r+dr, c+dc
        if cr < 0 or cr >= cfg.GRID_ROWS: return True   # wall/ceiling
        if cc < 0 or cc >= cfg.GRID_COLS: return True   # wall
        return board.grid[cr][cc] is not None

    filled = [occupied(dr,dc) for dr,dc in corners]
    filled_count = sum(filled)

    if filled_count < 3:
        return "none"

    # Determine which corners are "front" (the two the stem points toward)
    # T rotations: 0=North(stem up), 1=East(stem right), 2=South(stem down), 3=West(stem left)
    # Front = direction the flat face points (opposite the stem)
    front_map = {
        0: [2,3],   # North → bottom two corners (indices in 'corners' list) are front
        1: [0,2],   # East  → left two corners are front
        2: [0,1],   # South → top two corners are front
        3: [1,3],   # West  → right two corners are front
    }
    front_idx  = front_map[rot]
    front_filled = sum(filled[i] for i in front_idx)

    if front_filled == 2:
        return "tspin"       # both front corners → full T-spin
    else:
        return "tspin_mini"  # only 1 front corner → mini

# ---------------------------------------------------------------------------
#  Board / Piece / Bag
# ---------------------------------------------------------------------------
TOTAL_ROWS = cfg.GRID_ROWS + cfg.SPAWN_ROWS  # internal grid height

class Board:
    def __init__(self):
        # Row 0 = top visible row; rows -SPAWN_ROWS..-1 are above the grid
        # We use TOTAL_ROWS internally; display offset handles clipping
        self.grid = [[None]*cfg.GRID_COLS for _ in range(TOTAL_ROWS)]

    def _ri(self, row): return row + cfg.SPAWN_ROWS   # row index into self.grid

    def valid(self, cells):
        for r,c in cells:
            ri = self._ri(r)
            if c < 0 or c >= cfg.GRID_COLS: return False
            if ri >= TOTAL_ROWS: return False
            if ri >= 0 and self.grid[ri][c] is not None: return False
        return True

    def lock(self, piece):
        for r,c in piece.cells():
            ri = self._ri(r)
            if 0 <= ri < TOTAL_ROWS:
                self.grid[ri][c] = piece.type

    def clear_lines(self):
        # Only clear from the visible portion (rows 0..GRID_ROWS-1)
        vis_start = cfg.SPAWN_ROWS
        visible   = self.grid[vis_start:]
        new_vis   = [row for row in visible if any(cell is None for cell in row)]
        cleared   = cfg.GRID_ROWS - len(new_vis)
        empty     = [[None]*cfg.GRID_COLS for _ in range(cleared)]
        # Keep spawn rows intact; replace visible area
        self.grid = self.grid[:vis_start] + empty + new_vis
        return cleared

    def get_display_row(self, r):
        """Return row r (0-indexed from top visible) from the grid."""
        ri = self._ri(r)
        if 0 <= ri < TOTAL_ROWS: return self.grid[ri]
        return [None]*cfg.GRID_COLS

class Piece:
    def __init__(self, piece_type, theme):
        self.type     = piece_type
        self.rotation = 0
        # Spawn in the hidden zone above row 0
        self.row = -cfg.SPAWN_ROWS
        self.col = cfg.GRID_COLS // 2 - 1
        self.color = theme["piece_colors"][piece_type]

    def refresh_color(self, theme):
        self.color = theme["piece_colors"][self.type]

    def cells(self, row=None, col=None, rotation=None):
        r   = self.row      if row      is None else row
        c   = self.col      if col      is None else col
        rot = self.rotation if rotation is None else rotation
        return [(r+dr, c+dc) for dr,dc in PIECES[self.type][rot%4]]

class Bag:
    def __init__(self): self.bag=[]
    def next(self, theme):
        if not self.bag: self.bag=list(PIECES.keys()); random.shuffle(self.bag)
        return Piece(self.bag.pop(), theme)

# ===========================================================================
#  Main Menu
# ===========================================================================
class MainMenu:
    ITEMS = ["PLAY", "SETTINGS", "HIGH SCORES", "STATISTICS", "QUIT"]

    def __init__(self, screen):
        self.screen = screen
        self.sel    = 0
        self._anim  = 0.0
        self._item_rects = []
        self._bg_pieces  = []
        self._confirm_quit = False
        self._confirm_rects = {}
        self._rebuild_bg()
        self._make_fonts()

    def _make_fonts(self):
        self.f_title = make_font("consolas", 54, bold=True)
        self.f_item  = make_font("consolas", 28)
        self.f_sel   = make_font("consolas", 30, bold=True)
        self.f_small = make_font("consolas", 14)
        self.f_conf  = make_font("consolas", 22, bold=True)
        self.f_conf_s= make_font("consolas", 15)

    def _rebuild_bg(self):
        W,H = self.screen.get_size()
        colors = list(cfg.THEMES["default"]["piece_colors"].values())
        self._bg_pieces = [
            {"x":random.randint(0,W),"y":random.randint(0,H),
             "size":random.randint(14,30),"color":random.choice(colors),
             "speed":random.uniform(0.3,1.0),"alpha":random.randint(30,80)}
            for _ in range(18)]

    def handle_event(self, event):
        if self._confirm_quit:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: self._confirm_quit=False
                elif event.key in (pygame.K_RETURN, pygame.K_y): return "QUIT"
                elif event.key == pygame.K_n: self._confirm_quit=False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button==1:
                if self._confirm_rects.get("yes","") and self._confirm_rects["yes"].collidepoint(event.pos):
                    return "QUIT"
                if self._confirm_rects.get("no","") and self._confirm_rects["no"].collidepoint(event.pos):
                    self._confirm_quit=False
            return None  # eat all other events while confirm is up
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_UP,   pygame.K_w): self.sel=(self.sel-1)%len(self.ITEMS)
            elif event.key in (pygame.K_DOWN,pygame.K_s): self.sel=(self.sel+1)%len(self.ITEMS)
            elif event.key in (pygame.K_RETURN,pygame.K_SPACE):
                action = self.ITEMS[self.sel]
                if action == "QUIT": self._confirm_quit=True; return None
                return action
        if event.type == pygame.MOUSEMOTION:
            for i,rect in enumerate(self._item_rects):
                if rect.collidepoint(event.pos): self.sel=i
        if event.type == pygame.MOUSEBUTTONDOWN and event.button==1:
            for i,rect in enumerate(self._item_rects):
                if rect.collidepoint(event.pos):
                    action = self.ITEMS[i]
                    if action == "QUIT": self._confirm_quit=True; return None
                    return action
        return None

    def draw(self, dt):
        import math; self._anim += dt*0.002
        W,H = self.screen.get_size(); cx=W//2
        self.screen.fill((10,10,20))
        # drifting bg pieces
        for p in self._bg_pieces:
            p["y"] += p["speed"]*dt*0.06
            if p["y"] > H+40: p["y"]=-40; p["x"]=random.randint(0,W)
            s=pygame.Surface((p["size"],p["size"]),pygame.SRCALPHA)
            r,g,b=p["color"]; s.fill((r,g,b,p["alpha"])); self.screen.blit(s,(p["x"],p["y"]))
        # title
        wobble = int(math.sin(self._anim)*4)
        blit_centered(self.screen,"TETRIS",self.f_title,(80,180,255),cx,H//4-40+wobble)
        blit_centered(self.screen,"Arrow keys / mouse to navigate",self.f_small,(60,60,80),cx,H//4+30)
        # items
        item_h=52; start_y=H//2-(len(self.ITEMS)*item_h)//2; self._item_rects=[]
        for i,label in enumerate(self.ITEMS):
            y=start_y+i*item_h; sel=(i==self.sel)
            col=(255,220,50) if sel else (160,160,185)
            f=self.f_sel if sel else self.f_item
            surf=f.render(label,True,col); rx=cx-surf.get_width()//2
            self._item_rects.append(pygame.Rect(rx-10,y-4,surf.get_width()+20,surf.get_height()+8))
            if sel:
                pygame.draw.rect(self.screen,(30,30,55),self._item_rects[-1],border_radius=6)
                pygame.draw.rect(self.screen,(80,80,140),self._item_rects[-1],1,border_radius=6)
                blit_centered(self.screen,">> "+label+" <<",f,col,cx,y)
            else:
                blit_centered(self.screen,label,f,col,cx,y)
        blit_centered(self.screen,"Enter to select",self.f_small,(50,50,70),cx,H-30)

        # Quit confirmation popup
        if self._confirm_quit:
            dim=pygame.Surface((W,H),pygame.SRCALPHA); dim.fill((0,0,0,160))
            self.screen.blit(dim,(0,0))
            pw,ph=400,160; px=(W-pw)//2; py=(H-ph)//2
            pygame.draw.rect(self.screen,(25,15,15),(px,py,pw,ph),border_radius=10)
            pygame.draw.rect(self.screen,(180,60,60),(px,py,pw,ph),2,border_radius=10)
            ccx=px+pw//2
            blit_centered(self.screen,"Quit Tetris?",self.f_conf,(255,200,200),ccx,py+20)
            blit_centered(self.screen,"Are you sure you want to exit?",self.f_conf_s,(200,160,160),ccx,py+56)
            bw=110; gap=16; bx=px+(pw-bw*2-gap)//2
            yr=pygame.Rect(bx,py+96,bw,32)
            nr=pygame.Rect(bx+bw+gap,py+96,bw,32)
            self._confirm_rects={"yes":yr,"no":nr}
            pygame.draw.rect(self.screen,(60,15,15),yr,border_radius=4)
            pygame.draw.rect(self.screen,(255,80,80),yr,1,border_radius=4)
            pygame.draw.rect(self.screen,(15,50,15),nr,border_radius=4)
            pygame.draw.rect(self.screen,(80,200,80),nr,1,border_radius=4)
            blit_centered(self.screen,"Yes (Y)",self.f_conf_s,(255,100,100),yr.centerx,yr.y+8)
            blit_centered(self.screen,"No (N)",self.f_conf_s,(100,220,100),nr.centerx,nr.y+8)

# ===========================================================================
#  High Scores Screen
# ===========================================================================
class HighScoresScreen:
    def __init__(self, screen):
        self.screen=screen
        self.f_title=make_font("consolas",36,bold=True)
        self.f_entry=make_font("consolas",22)
        self.f_small=make_font("consolas",14)

    def handle_event(self, event):
        if event.type in (pygame.KEYDOWN,pygame.MOUSEBUTTONDOWN): return True
        return False

    def draw(self):
        W,H=self.screen.get_size(); cx=W//2
        scores=load_highscores(); t=cfg.THEMES.get(cfg.THEME,cfg.THEMES["default"])
        self.screen.fill(t["panel_bg"])
        blit_centered(self.screen,"HIGH SCORES",self.f_title,t["panel_value"],cx,40)
        pygame.draw.line(self.screen,t["border_color"],(cx-200,88),(cx+200,88),2)
        if not scores:
            blit_centered(self.screen,"No scores yet - play a game!",self.f_entry,t["panel_fg"],cx,H//2-20)
        else:
            medals=["  #1","  #2","  #3"]
            cols=[(255,215,0),(192,192,192),(205,127,50)]
            for i,s in enumerate(scores):
                y=106+i*38; rank=medals[i] if i<3 else f"  #{i+1}"
                col=cols[i] if i<3 else t["panel_fg"]
                blit_centered(self.screen,f"{rank}   {s:>12,}",self.f_entry,col,cx,y)
        pygame.draw.line(self.screen,t["border_color"],(cx-200,H-55),(cx+200,H-55),2)
        blit_centered(self.screen,"Press any key to return",self.f_small,t["panel_dim"],cx,H-40)

# ===========================================================================
#  Statistics Screen
# ===========================================================================
class StatisticsScreen:
    def __init__(self, screen):
        self.screen=screen
        self.f_title=make_font("consolas",34,bold=True)
        self.f_head=make_font("consolas",18,bold=True)
        self.f_row=make_font("consolas",16)
        self.f_small=make_font("consolas",13)

    def handle_event(self, event):
        if event.type in (pygame.KEYDOWN,pygame.MOUSEBUTTONDOWN): return True
        return False

    def draw(self):
        W,H=self.screen.get_size(); cx=W//2
        t=cfg.THEMES.get(cfg.THEME,cfg.THEMES["default"])
        s=load_stats()
        self.screen.fill(t["panel_bg"])
        blit_centered(self.screen,"STATISTICS",self.f_title,t["panel_value"],cx,30)
        pygame.draw.line(self.screen,t["border_color"],(cx-220,74),(cx+220,74),2)

        col_lbl = t["panel_fg"]; col_val = t["panel_value"]
        col_h   = t.get("popup_color", t["panel_value"])
        y=84; pad=30
        lx=pad; rx=W//2+10

        # ---- LEFT: All-time totals ----
        blit_left(self.screen,"ALL TIME",self.f_head,col_h,lx,y); y+=28
        rows=[
            ("Lines Cleared", f"{s['total_lines']:,}"),
            ("Score",         shorten(s["total_score"])),
            ("Blocks Placed", f"{s['total_blocks']:,}"),
        ]
        for lbl,val in rows:
            blit_left(self.screen,lbl,self.f_row,col_lbl,lx,y)
            blit_left(self.screen,val,self.f_row,col_val,lx+220,y); y+=24
        y+=6
        blit_left(self.screen,"By Piece Type",self.f_head,col_h,lx,y); y+=26
        for p in PIECE_TYPES:
            pc=t["piece_colors"][p]
            pygame.draw.rect(self.screen,pc,(lx,y+3,14,14))
            blit_left(self.screen,f"{p}:",self.f_row,col_lbl,lx+20,y)
            blit_left(self.screen,f"{s['total_by_type'].get(p,0):,}",self.f_row,col_val,lx+60,y)
            y+=22

        # ---- RIGHT: Best single game ----
        y2=84
        blit_left(self.screen,"BEST SINGLE GAME",self.f_head,col_h,rx,y2); y2+=28
        best_rows=[
            ("Score",  f"{s['best_score']:,}"),
            ("Lines",  f"{s['best_lines']:,}"),
            ("Level",  f"{s['best_level']:,}"),
            ("Blocks", f"{s['best_blocks']:,}"),
        ]
        for lbl,val in best_rows:
            blit_left(self.screen,lbl,self.f_row,col_lbl,rx,y2)
            blit_left(self.screen,val,self.f_row,col_val,rx+180,y2); y2+=24
        y2+=6
        blit_left(self.screen,"Best By Piece",self.f_head,col_h,rx,y2); y2+=26
        for p in PIECE_TYPES:
            pc=t["piece_colors"][p]
            pygame.draw.rect(self.screen,pc,(rx,y2+3,14,14))
            blit_left(self.screen,f"{p}:",self.f_row,col_lbl,rx+20,y2)
            blit_left(self.screen,f"{s['best_by_type'].get(p,0):,}",self.f_row,col_val,rx+60,y2)
            y2+=22

        pygame.draw.line(self.screen,t["border_color"],(cx-220,H-55),(cx+220,H-55),2)
        blit_centered(self.screen,"Press any key to return",self.f_small,t["panel_dim"],cx,H-40)

# ===========================================================================
#  Settings Screen
# ===========================================================================
KEYBIND_VARS = [
    ("KEY_MOVE_LEFT","Move Left"), ("KEY_MOVE_RIGHT","Move Right"),
    ("KEY_ROTATE_CW","Rotate CW"), ("KEY_ROTATE_CCW","Rotate CCW"),
    ("KEY_SOFT_DROP","Soft Drop"), ("KEY_HARD_DROP","Hard Drop"),
    ("KEY_HOLD","Hold"),           ("KEY_MUTE","Mute"),
    ("KEY_MINIMIZE","Minimize"),
]

class SettingsScreen:
    THEME_KEYS = list(cfg.THEMES.keys())

    def __init__(self, screen, game_ref=None):
        self.screen=screen; self.game=game_ref; self.open=False
        self._clickables={}; self._waiting_key=None
        self._section=None   # None/"keybinds"/"advanced"/"gameplay"/"difficulty"
        self._confirm=None   # None/"quit"/"reset"
        self._reset()

    def _reset(self):
        self._theme=cfg.THEME; self._volume=cfg.MUSIC_VOLUME
        self._muted=cfg.MUSIC_MUTED; self._cell_size=cfg.CELL_SIZE
        self._music_input=os.path.basename(cfg.MUSIC_FILE) if cfg.MUSIC_FILE else ""
        self._loop_start=cfg.MUSIC_LOOP_START_MS
        self._loop_end_trim=cfg.MUSIC_LOOP_END_TRIM_MS
        self._keys={v:getattr(cfg,v,"") for v,_ in KEYBIND_VARS}
        self._show_ghost=cfg.SHOW_GHOST
        self._soft_lock_drop=cfg.SOFT_LOCK_DROP
        self._next_count=cfg.NEXT_COUNT
        self._show_drop_stats=cfg.SHOW_DROP_STATS
        self._show_piece_preview=cfg.SHOW_PIECE_PREVIEW
        self._hold_enabled=cfg.HOLD_ENABLED
        self._start_level=cfg.START_LEVEL
        self._editing_music=False; self._status=""; self._status_t=0
        self._confirm=None; self._waiting_key=None

    def _mf(self):
        self.f_title=make_font("consolas",26,bold=True)
        self.f_lbl=make_font("consolas",16)
        self.f_val=make_font("consolas",16)
        self.f_sm=make_font("consolas",13)
        self.f_btn=make_font("consolas",15)

    def show(self):
        self.open=True; self._section=None; self._reset(); self._mf()
        if pygame.mixer.music.get_busy(): pygame.mixer.music.pause()

    def hide(self):
        self.open=False; self._waiting_key=None; self._confirm=None
        if not cfg.MUSIC_MUTED: pygame.mixer.music.unpause()

    # ---- event handling ----
    def handle_event(self, event):
        if not self.open: return False
        if self._waiting_key is not None:
            if event.type==pygame.KEYDOWN:
                kn=pygame.key.name(event.key)
                if event.key!=pygame.K_ESCAPE: self._keys[self._waiting_key]=kn
                self._waiting_key=None
            return True
        if self._confirm:
            if event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
                for n,r in self._clickables.items():
                    if r.collidepoint(event.pos): self._click(n); break
            if event.type==pygame.KEYDOWN and event.key==pygame.K_ESCAPE:
                self._confirm=None
            return True
        if event.type==pygame.KEYDOWN:
            if self._editing_music:
                if event.key==pygame.K_RETURN:   self._editing_music=False
                elif event.key==pygame.K_BACKSPACE: self._music_input=self._music_input[:-1]
                elif event.key==pygame.K_ESCAPE:  self._editing_music=False
                elif event.unicode and event.unicode.isprintable():
                    self._music_input+=event.unicode
            else:
                if event.key==pygame.K_ESCAPE:
                    self.hide()
                    if self.game: self.game.paused=False
            return True
        if event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
            for n,r in self._clickables.items():
                if r.collidepoint(event.pos): self._click(n); break
            return True
        return True

    def _click(self, name):
        # sections
        if name in ("sec_keybinds","sec_advanced","sec_gameplay","sec_difficulty"):
            key=name[4:]
            self._section=None if self._section==key else key
            return
        # presets
        if name.startswith("preset_"):
            pname=name[7:]
            if pname in cfg.KEYBIND_PRESETS:
                for k,v in cfg.KEYBIND_PRESETS[pname].items():
                    if k in self._keys: self._keys[k]=v
            return
        if name.startswith("bind_"):
            self._waiting_key=name[5:]; return
        actions = {
            "close":   lambda: (self.hide(), self.game and setattr(self.game,"paused",False)),
            "cancel":  lambda: (self.hide(), self.game and setattr(self.game,"paused",False)),
            "apply":   lambda: self._apply(),
            "theme_prev": lambda: self._cycle_theme(-1),
            "theme_next": lambda: self._cycle_theme(1),
            "vol_down":   lambda: setattr(self,"_volume",max(0.0,round(self._volume-0.05,2))),
            "vol_up":     lambda: setattr(self,"_volume",min(1.0,round(self._volume+0.05,2))),
            "mute_toggle":lambda: setattr(self,"_muted",not self._muted),
            "cell_down":  lambda: setattr(self,"_cell_size",max(16,self._cell_size-2)),
            "cell_up":    lambda: setattr(self,"_cell_size",min(48,self._cell_size+2)),
            "loop_s_dn":  lambda: setattr(self,"_loop_start",max(0,self._loop_start-50)),
            "loop_s_up":  lambda: setattr(self,"_loop_start",self._loop_start+50),
            "loop_e_dn":  lambda: setattr(self,"_loop_end_trim",max(0,self._loop_end_trim-50)),
            "loop_e_up":  lambda: setattr(self,"_loop_end_trim",self._loop_end_trim+50),
            "music_edit": lambda: setattr(self,"_editing_music",not self._editing_music),
            "ghost_tog":  lambda: setattr(self,"_show_ghost",not self._show_ghost),
            "softlock_tog":lambda:setattr(self,"_soft_lock_drop",not self._soft_lock_drop),
            "next_dn":    lambda: setattr(self,"_next_count",max(0,self._next_count-1)),
            "next_up":    lambda: setattr(self,"_next_count",min(5,self._next_count+1)),
            "dropstats_tog":lambda:setattr(self,"_show_drop_stats",not self._show_drop_stats),
            "preview_tog":lambda: setattr(self,"_show_piece_preview",not self._show_piece_preview),
            "hold_tog":   lambda: setattr(self,"_hold_enabled",not self._hold_enabled),
            "lvl_dn":     lambda: setattr(self,"_start_level",max(1,self._start_level-1)),
            "lvl_up":     lambda: setattr(self,"_start_level",min(29,self._start_level+1)),
            "quit_menu":  lambda: setattr(self,"_confirm","quit"),
            "reset_def":  lambda: setattr(self,"_confirm","reset"),
            "confirm_yes":lambda: self._do_confirm(),
            "confirm_no": lambda: setattr(self,"_confirm",None),
        }
        if name in actions: actions[name]()

    def _cycle_theme(self, d):
        keys=self.THEME_KEYS; idx=keys.index(self._theme) if self._theme in keys else 0
        self._theme=keys[(idx+d)%len(keys)]

    def _do_confirm(self):
        if self._confirm=="quit":
            self.hide()
            if self.game: self.game.request_quit=True
        elif self._confirm=="reset":
            for k,v in cfg.DEFAULT_SETTINGS.items(): setattr(cfg,k,v)
            try: cfg.save_settings(
                cfg.DEFAULT_SETTINGS["THEME"], cfg.DEFAULT_SETTINGS["MUSIC_VOLUME"],
                cfg.DEFAULT_SETTINGS["MUSIC_MUTED"], cfg.DEFAULT_SETTINGS["CELL_SIZE"],
                cfg.DEFAULT_SETTINGS.get("MUSIC_FILE",""),
                keys={v:cfg.DEFAULT_SETTINGS[v] for v,_ in KEYBIND_VARS if v in cfg.DEFAULT_SETTINGS},
                gameplay={k:cfg.DEFAULT_SETTINGS[k] for k in
                    ["SHOW_GHOST","SOFT_LOCK_DROP","NEXT_COUNT","SHOW_DROP_STATS","SHOW_PIECE_PREVIEW"]},
                difficulty={k:cfg.DEFAULT_SETTINGS[k] for k in ["HOLD_ENABLED","START_LEVEL"]},
            )
            except: pass
            if self.game: self.game.apply_theme(); self.game.rebuild_window()
            self._reset()
        self._confirm=None

    def _apply(self):
        inp=self._music_input.strip()
        base_dir=os.path.dirname(os.path.abspath(cfg.__file__))
        new_music=os.path.join(base_dir,inp) if inp and not os.path.isabs(inp) else inp
        cfg.THEME=self._theme; cfg.MUSIC_VOLUME=self._volume
        cfg.MUSIC_MUTED=self._muted; cfg.CELL_SIZE=self._cell_size
        cfg.MUSIC_FILE=new_music
        cfg.MUSIC_LOOP_START_MS=self._loop_start
        cfg.MUSIC_LOOP_END_TRIM_MS=self._loop_end_trim
        for var,val in self._keys.items(): setattr(cfg,var,val)
        cfg.SHOW_GHOST=self._show_ghost; cfg.SOFT_LOCK_DROP=self._soft_lock_drop
        cfg.NEXT_COUNT=self._next_count; cfg.SHOW_DROP_STATS=self._show_drop_stats
        cfg.SHOW_PIECE_PREVIEW=self._show_piece_preview
        cfg.HOLD_ENABLED=self._hold_enabled; cfg.START_LEVEL=self._start_level
        try:
            cfg.save_settings(
                self._theme, self._volume, self._muted, self._cell_size, new_music,
                self._loop_start, self._loop_end_trim,
                {v:self._keys[v] for v,_ in KEYBIND_VARS},
                {"SHOW_GHOST":self._show_ghost,"SOFT_LOCK_DROP":self._soft_lock_drop,
                 "NEXT_COUNT":self._next_count,"SHOW_DROP_STATS":self._show_drop_stats,
                 "SHOW_PIECE_PREVIEW":self._show_piece_preview},
                {"HOLD_ENABLED":self._hold_enabled,"START_LEVEL":self._start_level},
            )
        except Exception as e: self._status=f"Save failed: {e}"; self._status_t=time.time()
        if self.game:
            self.game.apply_theme(); self.game.apply_music(); self.game.rebuild_window()
        else: setup_music()
        self.hide()
        if self.game: self.game.paused=False

    # ---- drawing ----
    def draw(self):
        if not self.open: return
        self._clickables={}
        W,H=self.screen.get_size()
        dim=pygame.Surface((W,H),pygame.SRCALPHA); dim.fill((0,0,0,185))
        self.screen.blit(dim,(0,0))
        if self._confirm:    self._draw_confirm(W,H); return
        if self._waiting_key: self._draw_wait_key(W,H); return
        self._draw_main(W,H)

    def _draw_main(self,W,H):
        in_game=self.game is not None
        # First pass: measure content height, then draw
        sec_heights={"keybinds":len(KEYBIND_VARS)*28+56,"advanced":168,
                     "gameplay":175,"difficulty":96}
        content_h = 38                          # title
        if in_game: content_h += 18            # greyed note
        content_h += 14                        # divider
        content_h += 34*3                      # theme, volume, mute rows
        content_h += 34                        # reset defaults
        content_h += len([("keybinds","Keybinds"),("gameplay","Gameplay"),
                           ("difficulty","Difficulty"),("advanced","Advanced")])*32
        if self._section: content_h += sec_heights.get(self._section,0)
        if in_game: content_h += 44            # quit to menu
        content_h += 54                        # apply/cancel row + padding

        pw=530; ph=min(content_h+40, H-20)
        # If content taller than window, allow scrolling via clipping surface
        px=(W-pw)//2; py=(H-ph)//2

        pygame.draw.rect(self.screen,(22,22,38),(px,py,pw,ph),border_radius=12)
        pygame.draw.rect(self.screen,(80,80,130),(px,py,pw,ph),2,border_radius=12)

        # Draw into a sub-surface so content clips cleanly
        inner_h = content_h
        inner = pygame.Surface((pw, inner_h), pygame.SRCALPHA)
        inner.fill((0,0,0,0))

        cy=18; cx_i=pw//2; lx_val=260; arr=26

        def _ti(text,x,y,font,color,centred=False):
            surf=font.render(text,True,color)
            inner.blit(surf,(x-surf.get_width()//2 if centred else x,y))

        def _bi(rect,label,action,fg=(200,200,220),bg=(38,38,58),big=False):
            pygame.draw.rect(inner,bg,rect,border_radius=4)
            pygame.draw.rect(inner,fg,rect,1,border_radius=4)
            f=self.f_btn if big else self.f_sm
            surf=f.render(label,True,fg)
            inner.blit(surf,(rect.centerx-surf.get_width()//2,rect.centery-surf.get_height()//2))
            # register in screen-space clickables
            screen_rect=pygame.Rect(rect.x+px, rect.y+py+inner_offset, rect.width, rect.height)
            self._clickables[action]=screen_rect

        inner_offset=0  # how much of inner surface is scrolled (future use, 0 for now)

        _ti("SETTINGS",cx_i,cy,self.f_title,(190,190,255),True); cy+=38
        if in_game:
            _ti("Greyed settings can only be changed from the main menu",
                cx_i,cy,self.f_sm,(120,120,155),True); cy+=18
        pygame.draw.line(inner,(55,55,85),(20,cy),(pw-20,cy)); cy+=10

        # Theme
        _ti("Theme",20,cy+2,self.f_lbl,(170,170,200))
        _bi(pygame.Rect(lx_val,cy,arr,24),"<","theme_prev")
        _ti(cfg.THEMES[self._theme]["name"],lx_val+arr+65,cy+2,self.f_val,(255,240,100),True)
        _bi(pygame.Rect(lx_val+arr+130,cy,arr,24),">","theme_next"); cy+=34

        # Volume
        _ti("Volume",20,cy+2,self.f_lbl,(170,170,200))
        _bi(pygame.Rect(lx_val,cy,arr,24),"-","vol_down")
        _ti(f"{int(self._volume*100)}%",lx_val+arr+50,cy+2,self.f_val,(255,255,255),True)
        _bi(pygame.Rect(lx_val+arr+100,cy,arr,24),"+","vol_up"); cy+=34

        # Mute
        _ti("Mute",20,cy+2,self.f_lbl,(170,170,200))
        ml="ON" if self._muted else "OFF"; mc=(255,90,90) if self._muted else (80,210,80)
        _bi(pygame.Rect(lx_val,cy,60,24),ml,"mute_toggle",fg=mc,
            bg=(50,20,20) if self._muted else (15,45,15)); cy+=34

        # Reset defaults
        _bi(pygame.Rect(cx_i-60,cy,120,24),"Reset Defaults","reset_def",
            fg=(255,120,120),bg=(45,15,15)); cy+=34

        # Section toggles
        for sec_key,label in [("keybinds","Keybinds"),("gameplay","Gameplay"),
                               ("difficulty","Difficulty"),("advanced","Advanced")]:
            arrow="[-]" if self._section==sec_key else "[+]"
            _bi(pygame.Rect(cx_i-70,cy,140,24),f"{arrow} {label}",f"sec_{sec_key}",
                fg=(160,160,200),bg=(32,32,52)); cy+=32
            if self._section==sec_key:
                cy=self._draw_section_inner(inner,sec_key,0,cy,pw,in_game,
                                            px,py,inner_offset)+4

        # Quit to menu
        if in_game:
            _bi(pygame.Rect(cx_i-90,cy,180,28),"Quit to Menu","quit_menu",
                fg=(255,100,100),bg=(50,15,15)); cy+=38

        # Apply / Cancel — always at the bottom of content, never overlapping
        cy+=6
        bw=115; gap=18; bx=(pw-bw*2-gap)//2
        _bi(pygame.Rect(bx,cy,bw,34),"Apply","apply",fg=(50,200,80),bg=(18,50,22),big=True)
        _bi(pygame.Rect(bx+bw+gap,cy,bw,34),"Cancel","cancel",fg=(200,80,80),bg=(50,18,18),big=True)
        cy+=44

        # Blit inner surface onto screen (clipped to panel)
        clip_rect=pygame.Rect(0,0,pw,ph-0)
        self.screen.blit(inner,(px,py),clip_rect)

        # X close button drawn directly on screen (always visible)
        xr=pygame.Rect(px+pw-30,py+8,22,20)
        pygame.draw.rect(self.screen,(45,18,18),xr,border_radius=4)
        pygame.draw.rect(self.screen,(200,100,100),xr,1,border_radius=4)
        xs=self.f_sm.render("X",True,(200,100,100))
        self.screen.blit(xs,(xr.centerx-xs.get_width()//2,xr.centery-xs.get_height()//2))
        self._clickables["close"]=xr

        if self._status and time.time()-self._status_t<2.5:
            ss=self.f_sm.render(self._status,True,(140,240,140))
            self.screen.blit(ss,(px+(pw-ss.get_width())//2,py+ph+6))

    def _draw_section_inner(self,surf,sec,px_off,cy,pw,in_game,screen_px,screen_py,inner_offset):
        """Draw a section onto `surf`. screen_px/py used to register screen-space clickables."""
        pygame.draw.line(surf,(45,45,70),(20,cy),(pw-20,cy)); cy+=8
        lx=30; lx_val=260; arr=24; cx_i=pw//2

        def _ti(text,x,y,font,color,centred=False):
            s=font.render(text,True,color)
            surf.blit(s,(x-s.get_width()//2 if centred else x,y))

        def _bi(rect,label,action,fg=(200,200,220),bg=(38,38,58)):
            pygame.draw.rect(surf,bg,rect,border_radius=4)
            pygame.draw.rect(surf,fg,rect,1,border_radius=4)
            s=self.f_sm.render(label,True,fg)
            surf.blit(s,(rect.centerx-s.get_width()//2,rect.centery-s.get_height()//2))
            sr=pygame.Rect(rect.x+screen_px, rect.y+screen_py, rect.width, rect.height)
            self._clickables[action]=sr

        if sec=="keybinds":
            _ti("Preset:",lx,cy+2,self.f_sm,(160,160,180))
            bx=lx+60
            for pname in cfg.KEYBIND_PRESETS:
                _bi(pygame.Rect(bx,cy,80,22),pname,f"preset_{pname}",
                    fg=(200,200,100),bg=(40,40,15)); bx+=88
            cy+=30
            for var,label in KEYBIND_VARS:
                _ti(label,lx,cy+2,self.f_sm,(150,155,175))
                _bi(pygame.Rect(lx_val-20,cy,130,22),self._keys.get(var,"?"),
                    f"bind_{var}",fg=(255,220,100),bg=(40,35,15)); cy+=28
            pygame.draw.line(surf,(45,45,70),(20,cy),(pw-20,cy)); cy+=6

        elif sec=="gameplay":
            def tog_row(label,action,val):
                nonlocal cy
                _ti(label,lx,cy+2,self.f_sm,(150,155,175))
                c="ON" if val else "OFF"; mc=(80,210,80) if val else (180,80,80)
                _bi(pygame.Rect(lx_val-20,cy,55,22),c,action,fg=mc,
                    bg=(15,45,15) if val else (45,15,15)); cy+=28
            tog_row("Show Drop Preview","ghost_tog",self._show_ghost)
            tog_row("Soft-Lock Hard Drop","softlock_tog",self._soft_lock_drop)
            tog_row("Show Drop Stats","dropstats_tog",self._show_drop_stats)
            tog_row("Show Piece Preview","preview_tog",self._show_piece_preview)
            _ti("Next Pieces",lx,cy+2,self.f_sm,(150,155,175))
            _bi(pygame.Rect(lx_val-20,cy,arr,22),"-","next_dn")
            _ti(str(self._next_count),lx_val-20+arr+20,cy+2,self.f_sm,(255,255,255))
            _bi(pygame.Rect(lx_val-20+arr+50,cy,arr,22),"+","next_up"); cy+=28
            pygame.draw.line(surf,(45,45,70),(20,cy),(pw-20,cy)); cy+=6

        elif sec=="difficulty":
            _ti("Allow Hold",lx,cy+2,self.f_sm,(150,155,175))
            c="ON" if self._hold_enabled else "OFF"
            mc=(80,210,80) if self._hold_enabled else (180,80,80)
            _bi(pygame.Rect(lx_val-20,cy,55,22),c,"hold_tog",fg=mc,
                bg=(15,45,15) if self._hold_enabled else (45,15,15)); cy+=28
            grey=in_game
            _ti("Start Level",lx,cy+2,self.f_sm,(100,100,100) if grey else (150,155,175))
            if grey:
                _ti(str(cfg.START_LEVEL),lx_val,cy+2,self.f_sm,(90,90,90))
            else:
                _bi(pygame.Rect(lx_val-20,cy,arr,22),"-","lvl_dn")
                _ti(str(self._start_level),lx_val-20+arr+20,cy+2,self.f_sm,(255,255,255))
                _bi(pygame.Rect(lx_val-20+arr+50,cy,arr,22),"+","lvl_up")
            cy+=28
            pygame.draw.line(surf,(45,45,70),(20,cy),(pw-20,cy)); cy+=6

        elif sec=="advanced":
            _ti("Cell Size (px)",lx,cy+2,self.f_sm,(140,145,165))
            _bi(pygame.Rect(lx_val-20,cy,arr,22),"-","cell_down")
            _ti(str(self._cell_size),lx_val-20+arr+20,cy+2,self.f_sm,(255,255,255))
            _bi(pygame.Rect(lx_val-20+arr+50,cy,arr,22),"+","cell_up"); cy+=28
            _ti("Music File",lx,cy+2,self.f_sm,(140,145,165))
            box=pygame.Rect(170,cy-1,pw-190,24)
            pygame.draw.rect(surf,(55,75,55) if self._editing_music else (38,38,52),box,border_radius=3)
            pygame.draw.rect(surf,(90,140,90) if self._editing_music else (65,65,90),box,1,border_radius=3)
            disp=self._music_input+("|" if self._editing_music else "")
            surf.blit(self.f_sm.render(disp,True,(190,220,190)),(box.x+4,box.y+5))
            self._clickables["music_edit"]=pygame.Rect(box.x+screen_px,box.y+screen_py,box.w,box.h)
            cy+=30
            _ti("Loop Start (ms)",lx,cy+2,self.f_sm,(140,145,165))
            _bi(pygame.Rect(lx_val-20,cy,arr,22),"-","loop_s_dn")
            _ti(str(self._loop_start),lx_val-20+arr+20,cy+2,self.f_sm,(255,255,255))
            _bi(pygame.Rect(lx_val-20+arr+50,cy,arr,22),"+","loop_s_up"); cy+=28
            _ti("Loop End Trim (ms)",lx,cy+2,self.f_sm,(140,145,165))
            _bi(pygame.Rect(lx_val-20,cy,arr,22),"-","loop_e_dn")
            _ti(str(self._loop_end_trim),lx_val-20+arr+20,cy+2,self.f_sm,(255,255,255))
            _bi(pygame.Rect(lx_val-20+arr+50,cy,arr,22),"+","loop_e_up"); cy+=30
            pygame.draw.line(surf,(45,45,70),(20,cy),(pw-20,cy)); cy+=6
        return cy

    def _draw_confirm(self,W,H):
        is_reset=self._confirm=="reset"
        title="Reset to Defaults?" if is_reset else "Quit to Main Menu?"
        sub="All settings will be reset." if is_reset else "Current game will be lost."
        pw,ph=420,170; px=(W-pw)//2; py=(H-ph)//2
        pygame.draw.rect(self.screen,(25,15,15),(px,py,pw,ph),border_radius=10)
        pygame.draw.rect(self.screen,(180,60,60),(px,py,pw,ph),2,border_radius=10)
        cx=px+pw//2
        self._t(title,cx,py+18,self.f_title,(255,200,200),True)
        self._t(sub,cx,py+56,self.f_lbl,(200,160,160),True)
        bw=110; gap=18; bx=px+(pw-bw*2-gap)//2
        self._b(pygame.Rect(bx,py+100,bw,34),"Yes","confirm_yes",fg=(255,100,100),bg=(60,15,15),big=True)
        self._b(pygame.Rect(bx+bw+gap,py+100,bw,34),"Cancel","confirm_no",fg=(100,200,100),bg=(15,50,15),big=True)

    def _draw_wait_key(self,W,H):
        pw,ph=380,130; px=(W-pw)//2; py=(H-ph)//2
        pygame.draw.rect(self.screen,(15,20,35),(px,py,pw,ph),border_radius=10)
        pygame.draw.rect(self.screen,(80,80,180),(px,py,pw,ph),2,border_radius=10)
        label=next((l for v,l in KEYBIND_VARS if v==self._waiting_key),"?")
        cx=px+pw//2
        self._t("Press a key for:",cx,py+22,self.f_lbl,(180,180,220),True)
        self._t(label,cx,py+50,self.f_title,(255,240,120),True)
        self._t("ESC to cancel",cx,py+90,self.f_sm,(100,100,130),True)

    def _t(self,text,x,y,font,color,cx=False):
        surf=font.render(text,True,color)
        self.screen.blit(surf,(x-surf.get_width()//2 if cx else x,y))

    def _b(self,rect,label,action,fg=(200,200,220),bg=(38,38,58),big=False):
        pygame.draw.rect(self.screen,bg,rect,border_radius=4)
        pygame.draw.rect(self.screen,fg,rect,1,border_radius=4)
        f=self.f_btn if big else self.f_sm
        surf=f.render(label,True,fg)
        self.screen.blit(surf,(rect.centerx-surf.get_width()//2,rect.centery-surf.get_height()//2))
        self._clickables[action]=rect

# ===========================================================================
#  Tetris game
# ===========================================================================
class Tetris:
    def __init__(self, screen):
        self.screen=screen; self.theme=cfg.THEMES.get(cfg.THEME,cfg.THEMES["default"])
        self._build_fonts(); self.music_loaded=setup_music()
        self.settings=SettingsScreen(screen, self)
        self.request_quit=False
        self.reset()

    def _build_fonts(self):
        t=self.theme
        self.font_large=make_font(*t["font_large"],bold=True)
        self.font_med=make_font(*t["font_panel"])
        self.font_sm=make_font(*t["font_label"])

    def rebuild_window(self):
        W,H=self.screen.get_size()
        self.screen=pygame.display.set_mode((W,H),pygame.RESIZABLE)
        self.settings.screen=self.screen
        self.theme=cfg.THEMES.get(cfg.THEME,cfg.THEMES["default"])
        self._build_fonts()

    def apply_theme(self):
        self.theme=cfg.THEMES.get(cfg.THEME,cfg.THEMES["default"]); self._build_fonts()
        if hasattr(self,"current"): self.current.refresh_color(self.theme)
        if hasattr(self,"next_pieces"):
            for p in self.next_pieces: p.refresh_color(self.theme)

    def apply_music(self): self.music_loaded=setup_music()

    def reset(self):
        self.theme=cfg.THEMES.get(cfg.THEME,cfg.THEMES["default"])
        self.board=Board(); self.bag=Bag()
        self.score=0; self.lines=0; self.level=cfg.START_LEVEL
        self.game_over=False; self.paused=False; self.request_quit=False
        self.held_type=None; self.hold_used=False
        self.next_pieces=[self.bag.next(self.theme) for _ in range(5)]
        self.current=self._spawn(); self.last_was_rotation=False
        self.last_kick_was_wall=False  # for mini T-spin detection
        self.gravity_timer=time.time(); self.lock_timer=None; self.lock_resets=0
        self.soft_dropping=False; self.soft_drop_timer=time.time()
        self.b2b=False; self.popup_text=""; self.popup_timer=0
        self.das_key=None; self.das_t=0; self.das_charged=False
        self.DAS_DELAY=170; self.ARR=50
        self._soft_lock_free=False
        # per-game stats
        self.blocks_placed=0; self.pieces_placed={p:0 for p in PIECE_TYPES}
        self._build_fonts()

    def _spawn(self):
        p=self.next_pieces.pop(0); self.next_pieces.append(self.bag.next(self.theme))
        p.row=-cfg.SPAWN_ROWS; p.col=cfg.GRID_COLS//2-1; return p

    # ---- movement ----
    def _try_move(self,dr,dc):
        nc=self.current.cells(self.current.row+dr,self.current.col+dc)
        if self.board.valid(nc):
            self.current.row+=dr; self.current.col+=dc
            if dc!=0: self.last_was_rotation=False; self._reset_lock()
            return True
        return False

    def _try_rotate(self,direction=1):
        p=self.current; old=p.rotation; new=(old+direction)%4
        for dc,dr in get_kicks(p.type).get((old,new),[(0,0)]):
            test_row = p.row+dr
            # Never let a kick push the piece above the spawn ceiling
            test_row = max(test_row, -cfg.SPAWN_ROWS)
            if self.board.valid(p.cells(test_row,p.col+dc,new)):
                p.rotation=new; p.row=test_row; p.col+=dc
                self.last_was_rotation=True
                self._reset_lock()
                return True
        return False

    def _reset_lock(self):
        if self.lock_timer is not None:
            if getattr(self, '_soft_lock_free', False):
                # First action after a soft-lock hard drop is free
                self._soft_lock_free = False
                self.lock_timer = time.time()   # reset timer but don't charge a reset
                return
            if self.lock_resets < cfg.LOCK_RESETS_MAX:
                self.lock_timer = time.time(); self.lock_resets += 1

    def _on_ground(self):
        return not self.board.valid(self.current.cells(self.current.row+1,self.current.col))

    def _ghost_row(self):
        r=self.current.row
        while self.board.valid(self.current.cells(r+1,self.current.col)): r+=1
        return r

    def _hard_drop(self):
        dist=0
        while self._try_move(1,0): dist+=1
        self.score+=dist*cfg.SCORE_HARD_DROP_PER_ROW
        if cfg.SOFT_LOCK_DROP:
            # First action is free; set flag so _reset_lock skips the first call
            self.lock_timer=time.time()
            self.lock_resets=0
            self._soft_lock_free=True   # next rotation/move won't cost a reset
        else:
            self._lock_piece()

    def _lock_piece(self):
        tspin=detect_tspin(self.board,self.current,self.last_was_rotation)
        self.board.lock(self.current)
        self.blocks_placed+=1; self.pieces_placed[self.current.type]=self.pieces_placed.get(self.current.type,0)+1
        cleared=self.board.clear_lines()
        self._apply_score(cleared,tspin)
        self.lines+=cleared; self.level=max(self.level,self.lines//cfg.LINES_PER_LEVEL+cfg.START_LEVEL)
        self.hold_used=False; self.current=self._spawn(); self.last_was_rotation=False
        if not self.board.valid(self.current.cells()):
            self.game_over=True
            save_highscore(self.score)
            record_game(self.score,self.lines,self.level,self.blocks_placed,self.pieces_placed)
        self.lock_timer=None; self.lock_resets=0

    def _apply_score(self,cleared,tspin):
        base=0; label=""; is_special=False
        if tspin=="tspin":
            is_special=True
            table=[(cfg.SCORE_TSPIN,"T-Spin"),
                   (cfg.SCORE_TSPIN_SINGLE,"T-Spin Single!"),
                   (cfg.SCORE_TSPIN_DOUBLE,"T-Spin Double!"),
                   (cfg.SCORE_TSPIN_TRIPLE,"T-Spin Triple!")]
            base,label=table[min(cleared,3)]
        elif tspin=="tspin_mini":
            is_special=True
            table=[(cfg.SCORE_TSPIN_MINI,"T-Spin Mini"),
                   (cfg.SCORE_TSPIN_MINI_SINGLE,"T-Spin Mini Single")]
            base,label=table[min(cleared,1)]
        else:
            if cleared==1: base,label=cfg.SCORE_SINGLE,"Single"
            elif cleared==2: base,label=cfg.SCORE_DOUBLE,"Double"
            elif cleared==3: base,label=cfg.SCORE_TRIPLE,"Triple"
            elif cleared>=4: base,label,is_special=cfg.SCORE_TETRIS,"TETRIS!",True
        if base>0:
            if is_special and self.b2b:
                base+=int(base*cfg.SCORE_B2B_BONUS_FACTOR); label="B2B "+label
            self.b2b=is_special; self.score+=base*self.level
            self.popup_text=label; self.popup_timer=time.time()

    def _hold(self):
        if not cfg.HOLD_ENABLED or self.hold_used: return
        if self.held_type is None:
            self.held_type=self.current.type; self.current=self._spawn()
        else:
            self.held_type,nt=self.current.type,self.held_type
            self.current=Piece(nt,self.theme); self.current.refresh_color(self.theme)
        self.hold_used=True; self.last_was_rotation=False

    def update(self,dt_ms):
        if self.game_over or self.paused: return
        now=time.time()
        # DAS/ARR
        if self.das_key:
            if not self.das_charged:
                self.das_t+=dt_ms
                if self.das_t>=self.DAS_DELAY: self.das_charged=True; self.das_t=0
            else:
                self.das_t+=dt_ms
                while self.das_t>=self.ARR:
                    self.das_t-=self.ARR
                    if self.das_key=="left":  self._try_move(0,-1)
                    elif self.das_key=="right": self._try_move(0,1)
        # Soft drop
        if self.soft_dropping:
            if now-self.soft_drop_timer>=cfg.SOFT_DROP_INTERVAL:
                self.soft_drop_timer=now
                if self._try_move(1,0): self.score+=cfg.SCORE_SOFT_DROP_PER_ROW
        # Gravity
        if not self.soft_dropping:
            if now-self.gravity_timer>=gravity_interval(self.level):
                self.gravity_timer=now; self._try_move(1,0)
        # Lock delay
        if self._on_ground():
            if self.lock_timer is None: self.lock_timer=now; self.lock_resets=0
            elif now-self.lock_timer>=cfg.LOCK_DELAY: self._lock_piece()
        else: self.lock_timer=None

    def handle_event(self,event):
        if self.settings.handle_event(event): return None
        if event.type==MUSIC_END_EVENT: handle_music_end(); return None
        if event.type==pygame.KEYDOWN:
            k=pygame.key.name(event.key)
            if self.game_over: return "menu"
            if k=="escape":
                self.paused=not self.paused
                if self.paused: self.settings.show()
                else: self.settings.hide()
                return None
            if self.paused: return None
            if k==cfg.KEY_MINIMIZE: pygame.display.iconify(); self.paused=True; self.settings.show(); return None
            if k==cfg.KEY_MOVE_LEFT:
                self._try_move(0,-1); self.das_key="left"; self.das_t=0; self.das_charged=False
            elif k==cfg.KEY_MOVE_RIGHT:
                self._try_move(0,1); self.das_key="right"; self.das_t=0; self.das_charged=False
            elif k==cfg.KEY_ROTATE_CW:  self._try_rotate(1)
            elif k==cfg.KEY_ROTATE_CCW: self._try_rotate(-1)
            elif k==cfg.KEY_SOFT_DROP:  self.soft_dropping=True; self.soft_drop_timer=time.time()
            elif k==cfg.KEY_HARD_DROP:  self._hard_drop()
            elif k==cfg.KEY_HOLD:       self._hold()
            elif k==cfg.KEY_MUTE:       self._toggle_mute()
            elif k=="up":   self._change_volume(0.05)
            elif k=="down": self._change_volume(-0.05)
        elif event.type==pygame.KEYUP:
            k=pygame.key.name(event.key)
            if k==cfg.KEY_MOVE_LEFT  and self.das_key=="left":  self.das_key=None
            if k==cfg.KEY_MOVE_RIGHT and self.das_key=="right": self.das_key=None
            if k==cfg.KEY_SOFT_DROP: self.soft_dropping=False
        if self.request_quit: return "menu"
        return None

    def _toggle_mute(self):
        cfg.MUSIC_MUTED=not cfg.MUSIC_MUTED
        pygame.mixer.music.set_volume(0 if cfg.MUSIC_MUTED else cfg.MUSIC_VOLUME)

    def _change_volume(self,delta):
        cfg.MUSIC_VOLUME=max(0.0,min(1.0,round(cfg.MUSIC_VOLUME+delta,2)))
        if not cfg.MUSIC_MUTED: pygame.mixer.music.set_volume(cfg.MUSIC_VOLUME)

    def draw(self):
        W,H=self.screen.get_size(); L=calc_layout(W,H)
        ox=L["ox"]; oy=L["oy"]; s=L["s"]
        t=self.theme
        self.screen.fill(t["panel_bg"])
        # Piece preview strip above grid
        if cfg.SHOW_PIECE_PREVIEW: self._draw_preview(L)
        # Grid
        draw_grid(self.screen,self.board,ox,oy,s,t)
        # Ghost
        if cfg.SHOW_GHOST:
            gr=self._ghost_row()
            draw_ghost(self.screen,self.current.cells(gr,self.current.col),ox,oy,
                       self.current.color,t["ghost_alpha"],t.get("calc_outline",False),s)
        # Active piece (only visible rows)
        for r,c in self.current.cells():
            if r >= 0:
                draw_cell(self.screen,self.current.color,r,c,ox,oy,s,
                          bevel=t.get("use_bevel",True),dither=t.get("retro_dither",False))
        if t.get("scanlines"): draw_scanlines(self.screen,ox,oy,s)
        pygame.draw.rect(self.screen,t["border_color"],(ox,oy,L["gw"],L["gh"]),2)
        self._draw_panels(L)
        if self.paused and not self.settings.open: self._draw_overlay(W,H,"PAUSED","ESC to resume")
        if self.game_over: self._draw_overlay(W,H,"GAME OVER",f"Score: {self.score}   Any key for menu")
        self.settings.draw()
        pygame.display.flip()

    def _draw_preview(self,L):
        """Draw current piece centered above the grid at 50% grid width."""
        ox=L["ox"]; oy=L["oy"]; s=L["s"]
        gw=L["gw"]; prev_h=L["preview_h"]
        # Box is 50% of grid width, centered
        box_w=gw//2; box_x=ox+gw//4
        box_y=oy-prev_h
        t=self.theme
        # Background box
        pygame.draw.rect(self.screen,t["grid_bg"],(box_x,box_y,box_w,prev_h-4),border_radius=4)
        pygame.draw.rect(self.screen,t["border_color"],(box_x,box_y,box_w,prev_h-4),1,border_radius=4)
        # Draw piece
        cs=min(s-2,18)
        mini_piece(self.screen,self.current.type,
                   box_x+box_w//2, box_y+(prev_h-4)//2, t, cs)

    def _draw_panels(self,L):
        t=self.theme; ox=L["ox"]; oy=L["oy"]; s=L["s"]
        gw=L["gw"]; gh=L["gh"]
        lx=L["panel_left_cx"]; rx=L["panel_right_cx"]

        # ---- RIGHT: NEXT ----
        self._lbl("NEXT",rx,oy+4)
        nc=cfg.NEXT_COUNT
        for i,p in enumerate(self.next_pieces[:nc]):
            mini_piece(self.screen,p.type,rx,oy+46+i*50,t,min(s-4,18))

        # ---- LEFT: HOLD ----
        self._lbl("HOLD",lx,oy+4)
        if self.held_type:
            mini_piece(self.screen,self.held_type,lx,oy+46,t,min(s-4,18),
                       outline=self.hold_used)

        # SCORE / LEVEL / LINES
        sy=oy+100
        for lbl,val in [("SCORE",str(self.score)),("LEVEL",str(self.level)),("LINES",str(self.lines))]:
            self._lbl(lbl,lx,sy); self._val(val,lx,sy+20); sy+=62

        # ---- DROP STATS ----
        if cfg.SHOW_DROP_STATS:
            dy=oy+310
            self._lbl("PIECES",lx,dy); dy+=22
            dot_size=10; dot_gap=4
            for p in PIECE_TYPES:
                pc=t["piece_colors"][p]
                # dot left of the label, centred on lx
                dot_x = lx - 28; dot_y = dy + 3
                pygame.draw.rect(self.screen,pc,(dot_x,dot_y,dot_size,dot_size))
                surf=self.font_sm.render(f"{p}:{self.pieces_placed.get(p,0)}",True,t["panel_fg"])
                self.screen.blit(surf,(dot_x+dot_size+dot_gap, dy)); dy+=18

        # Music hint bottom-left
        my=oy+gh-22
        if self.music_loaded:
            status="MUTED" if cfg.MUSIC_MUTED else f"VOL {int(cfg.MUSIC_VOLUME*100)}%"
            self._dim(status,lx,my)

        # Popup
        if self.popup_text and time.time()-self.popup_timer<1.5:
            alpha=max(0,255-int((time.time()-self.popup_timer)/1.5*255))
            surf=self.font_large.render(self.popup_text,True,t["popup_color"])
            surf.set_alpha(alpha)
            self.screen.blit(surf,(ox+(gw-surf.get_width())//2,oy+gh//2-20))

        # HI score — centred above grid
        scores=load_highscores()
        if scores:
            surf=self.font_sm.render(f"HI {scores[0]:,}",True,t["hud_text"])
            self.screen.blit(surf,(ox+(gw-surf.get_width())//2,oy-surf.get_height()-4))

    def _draw_overlay(self,W,H,title,sub):
        ov=pygame.Surface((W,H),pygame.SRCALPHA); ov.fill(self.theme["overlay_bg"])
        self.screen.blit(ov,(0,0)); cx=W//2; cy=H//2
        t_=self.font_large.render(title,True,self.theme["overlay_title"])
        s_=self.font_med.render(sub,True,self.theme["overlay_sub"])
        self.screen.blit(t_,(cx-t_.get_width()//2,cy-28))
        self.screen.blit(s_,(cx-s_.get_width()//2,cy+10))

    def _lbl(self,t,cx,y):
        s=self.font_sm.render(t,True,self.theme["panel_fg"]); self.screen.blit(s,(cx-s.get_width()//2,y))
    def _val(self,t,cx,y):
        s=self.font_med.render(t,True,self.theme["panel_value"]); self.screen.blit(s,(cx-s.get_width()//2,y))
    def _dim(self,t,cx,y):
        s=self.font_sm.render(t,True,self.theme["panel_dim"]); self.screen.blit(s,(cx-s.get_width()//2,y))

# ===========================================================================
#  App
# ===========================================================================
class App:
    S_MENU="menu"; S_GAME="game"; S_SCORES="scores"; S_STATS="stats"

    def __init__(self):
        pygame.init(); pygame.mixer.init()
        self.screen=pygame.display.set_mode((900,700),pygame.RESIZABLE)
        pygame.display.set_caption(cfg.WINDOW_TITLE)
        self.clock=pygame.time.Clock(); self.state=self.S_MENU
        self.menu=MainMenu(self.screen); self.game=None
        self.hi_screen=HighScoresScreen(self.screen)
        self.stat_screen=StatisticsScreen(self.screen)
        self.menu_settings=SettingsScreen(self.screen,game_ref=None)
        setup_music()

    def run(self):
        while True:
            dt=self.clock.tick(cfg.FPS)
            for event in pygame.event.get():
                if event.type==pygame.QUIT: pygame.quit(); sys.exit()
                if event.type==MUSIC_END_EVENT: handle_music_end()
                if event.type==pygame.VIDEORESIZE:
                    self.screen=pygame.display.set_mode((event.w,event.h),pygame.RESIZABLE)
                    self._propagate_screen()
                # Global mute / minimize keys work everywhere
                if event.type==pygame.KEYDOWN:
                    k=pygame.key.name(event.key)
                    if k==cfg.KEY_MUTE:
                        cfg.MUSIC_MUTED=not cfg.MUSIC_MUTED
                        pygame.mixer.music.set_volume(0 if cfg.MUSIC_MUTED else cfg.MUSIC_VOLUME)
                    elif k==cfg.KEY_MINIMIZE:
                        pygame.display.iconify()
                        if self.state==self.S_GAME and self.game and not self.game.paused:
                            self.game.paused=True; self.game.settings.show()
                self._handle_event(event,dt)
            self._update(dt); self._draw(dt)

    def _propagate_screen(self):
        self.menu.screen=self.screen
        self.hi_screen.screen=self.screen
        self.stat_screen.screen=self.screen
        self.menu_settings.screen=self.screen
        if self.game:
            self.game.screen=self.screen; self.game.settings.screen=self.screen

    def _handle_event(self,event,dt):
        if self.state==self.S_MENU:
            if self.menu_settings.open:
                self.menu_settings.handle_event(event)
                if not self.menu_settings.open: self._propagate_screen()
            else:
                action=self.menu.handle_event(event)
                if action=="PLAY":        self._start_game()
                elif action=="SETTINGS":  self.menu_settings.screen=self.screen; self.menu_settings.show()
                elif action=="HIGH SCORES": self.state=self.S_SCORES
                elif action=="STATISTICS":  self.state=self.S_STATS
                elif action=="QUIT":      pygame.quit(); sys.exit()
        elif self.state==self.S_GAME:
            result=self.game.handle_event(event)
            if result=="menu": self.state=self.S_MENU
        elif self.state==self.S_SCORES:
            if self.hi_screen.handle_event(event): self.state=self.S_MENU
        elif self.state==self.S_STATS:
            if self.stat_screen.handle_event(event): self.state=self.S_MENU

    def _start_game(self):
        if self.game is None: self.game=Tetris(self.screen)
        else: self.game.screen=self.screen; self.game.settings.screen=self.screen; self.game.reset()
        self.state=self.S_GAME

    def _update(self,dt):
        if self.state==self.S_GAME and self.game: self.game.update(dt)

    def _draw(self,dt):
        if self.state==self.S_MENU:
            self.menu.draw(dt); self.menu_settings.draw()
        elif self.state==self.S_GAME and self.game: self.game.draw()
        elif self.state==self.S_SCORES: self.hi_screen.draw()
        elif self.state==self.S_STATS:  self.stat_screen.draw()
        pygame.display.flip()

if __name__=="__main__":
    App().run()